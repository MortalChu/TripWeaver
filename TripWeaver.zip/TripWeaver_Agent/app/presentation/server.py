"""TripWeaver LangGraph 旅行服务入口。"""
from app.presentation.travel_server import app, build_app
