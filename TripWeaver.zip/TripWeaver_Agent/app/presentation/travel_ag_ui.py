"""框架无关的旅行 AG-UI 路由与 LangGraph 事件适配。"""
import asyncio
import copy
import json
from ag_ui.core import (RunAgentInput, RunStartedEvent, RunFinishedEvent, RunErrorEvent,
    StateSnapshotEvent, TextMessageStartEvent, TextMessageContentEvent, TextMessageEndEvent,
    ToolCallStartEvent, ToolCallArgsEvent, ToolCallEndEvent, ToolCallResultEvent, CustomEvent)
from fastapi import HTTPException, Request, Query
from fastapi.responses import StreamingResponse
from app.application.agents.contracts import SubmitIntentInput
from app.infrastructure.ag_ui_journal import JournalConflict, JournalForbidden, JournalNotFound
from app.presentation.identity import require_buyer, require_session


class TravelAGUIAdapter:
    def __init__(self, request, emit, authoritative_state=None):
        self.request, self.emit = request, emit
        self.state = {"status":"running", "toolApprovals":[], "framework":"langgraph"}
        self.error = None
        self.text_seen = False
        self.open_text = set()

    def snapshot(self):
        self.emit(StateSnapshotEvent(snapshot=copy.deepcopy(self.state)))

    def start(self):
        self.emit(RunStartedEvent(thread_id=self.request.thread_id,run_id=self.request.run_id))
        self.snapshot()

    def on_trade_event(self, event):
        # 业务证据仍由 SQLite 保存，SSE 不重复携带大段工具原文。
        if event.type == "agent.dispatch":
            self.emit(CustomEvent(name="agent.dispatch",value={"framework":"langgraph"}))

    def on_agent_event(self, event):
        kind = event["type"]
        identifier = f"{self.request.run_id}:{event.get('id','final')}"
        if kind == "text_start":
            self.open_text.add(identifier)
            self.emit(TextMessageStartEvent(message_id=identifier,role="assistant"))
        elif kind == "text_delta":
            self.text_seen = True
            self.emit(TextMessageContentEvent(message_id=identifier,delta=event["text"]))
        elif kind == "text_end":
            self.open_text.discard(identifier)
            self.emit(TextMessageEndEvent(message_id=identifier))
        elif kind == "tool_start":
            self.emit(ToolCallStartEvent(tool_call_id=identifier,tool_call_name=event["name"]))
            self.emit(ToolCallArgsEvent(tool_call_id=identifier,delta=json.dumps(event["args"],ensure_ascii=False)))
            self.emit(ToolCallEndEvent(tool_call_id=identifier))
        elif kind == "tool_result":
            self.emit(ToolCallResultEvent(message_id=identifier+":result",tool_call_id=identifier,
                content=event["content"],role="tool"))
        elif kind == "approval":
            self.state.update(status="awaiting_confirmation",toolApprovals=event["approvals"])
            self.snapshot()
        elif kind == "dispatch":
            self.emit(CustomEvent(name="agent.dispatch",value={"agent":event["role"]}))

    def finish(self,text):
        if text and not self.text_seen:
            self.on_agent_event({"type":"text_start","id":"final"})
            self.on_agent_event({"type":"text_delta","id":"final","text":text})
            self.on_agent_event({"type":"text_end","id":"final"})
        if not self.state["toolApprovals"]:
            self.state["status"] = "completed"
        self.snapshot()
        self.emit(RunFinishedEvent(thread_id=self.request.thread_id,run_id=self.request.run_id))

    def fail(self,message,cancelled=False,code=None):
        for identifier in list(self.open_text):
            self.emit(TextMessageEndEvent(message_id=identifier))
        self.state["status"] = "cancelled" if cancelled else "error"
        self.snapshot()
        self.emit(RunErrorEvent(message=message,code=code or ("CANCELLED" if cancelled else "AGENT_ERROR")))


def register_travel_agent_routes(api,get_runtime):
    def translate(error):
        return HTTPException(403 if isinstance(error,JournalForbidden) else 404 if isinstance(error,JournalNotFound) else 409,str(error))

    def cursor(request,run_id,after):
        value = request.headers.get("last-event-id")
        if value:
            prefix,separator,number = value.rpartition(":")
            if not separator or prefix != run_id or not number.isdigit():
                raise HTTPException(409,"Last-Event-ID 与当前运行不匹配")
            return int(number)
        return after

    async def replay(manager,run_id,buyer,after):
        while True:
            events,status,last = await manager.journal.events(run_id,buyer,after)
            for item in events:
                after = item["seq"]
                yield f"id: {run_id}:{after}\ndata: {json.dumps(item['event'],ensure_ascii=False)}\n\n"
            if status != "running" and after >= last:
                return
            if not events:
                yield ": keep-alive\n\n"
                await asyncio.sleep(.15)

    def response(manager,run,buyer,after):
        return StreamingResponse(replay(manager,run,buyer,after),media_type="text/event-stream",
            headers={"Cache-Control":"no-cache, no-transform","X-Accel-Buffering":"no","X-Run-Id":run})

    @api.post("/travel/agent/run")
    async def start(body:RunAgentInput,request:Request):
        if not body.thread_id.strip() or not body.run_id.strip() or body.tools or not body.messages or body.messages[-1].role != "user":
            raise HTTPException(422,"需要有效 threadId/runId 和最后一条 user 消息，仅支持后端工具")
        text = body.messages[-1].content
        if not isinstance(text,str) or not text.strip():
            raise HTTPException(422,"用户消息不能为空")
        props = body.forwarded_props if isinstance(body.forwarded_props,dict) else {}
        buyer = await require_buyer(request,props.get("buyerId"))
        await require_session(request,buyer,body.thread_id,create=True)
        confirmations=[]
        for entry in body.resume or []:
            payload=entry.payload
            if entry.status=="cancelled":
                approved=False
            elif isinstance(payload,dict) and set(payload)=={"approved"} and type(payload["approved"]) is bool:
                approved=payload["approved"]
            else:
                raise HTTPException(422,"确认只接受 approved 布尔值")
            confirmations.append({"interrupt_id":entry.interrupt_id,"approved":approved})
        if len(confirmations)>20:
            raise HTTPException(422,"单次确认过多")
        intent=SubmitIntentInput(body.thread_id,buyer,"zh-CN","CNY",text.strip(),confirmations=tuple(confirmations))
        manager=get_runtime()
        try:
            after=cursor(request,body.run_id,0)
            if after:
                await manager.journal.events(body.run_id,buyer,after)
            await manager.start(body,intent)
            return response(manager,body.run_id,buyer,after)
        except (JournalConflict,JournalForbidden,JournalNotFound) as error:
            raise translate(error) from error

    @api.get("/travel/agent/runs/{run_id}/events")
    async def events(run_id:str,request:Request,buyer_id:str=Query(min_length=1),after:int=Query(0,ge=0)):
        await require_buyer(request,buyer_id)
        manager=get_runtime()
        try:
            run=await manager.journal.run(run_id,buyer_id)
            await require_session(request,buyer_id,run["threadId"])
            after=cursor(request,run_id,after)
            await manager.journal.events(run_id,buyer_id,after)
            return response(manager,run_id,buyer_id,after)
        except (JournalConflict,JournalForbidden,JournalNotFound) as error:
            raise translate(error) from error

    @api.get("/travel/agent/runs/{run_id}")
    async def run(run_id:str,request:Request,buyer_id:str=Query(min_length=1)):
        await require_buyer(request,buyer_id)
        try:
            return await get_runtime().journal.run(run_id,buyer_id)
        except (JournalConflict,JournalForbidden,JournalNotFound) as error:
            raise translate(error) from error

    @api.post("/travel/agent/runs/{run_id}/cancel")
    async def cancel(run_id:str,request:Request,buyer_id:str=Query(min_length=1)):
        await require_buyer(request,buyer_id)
        try:
            return await get_runtime().cancel(run_id,buyer_id)
        except (JournalConflict,JournalForbidden,JournalNotFound) as error:
            raise translate(error) from error
