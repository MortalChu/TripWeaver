"""TripWeaver HTTP 入口。默认演示模式不调用任何模型或外部地图。"""
from __future__ import annotations

import asyncio
import json
from contextlib import asynccontextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Literal

from fastapi import FastAPI,HTTPException,Query,Request
from fastapi.responses import JSONResponse,FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import Field

from app.domain.travel.models import StrictModel,TripRequest,ReplanRequest
from app.domain.buyer.preference import BuyerPreference,MemoryConflict
from app.infrastructure.travel_store import TripConflict
from app.presentation.identity import require_buyer,require_session
from app.presentation.travel_ag_ui import register_travel_agent_routes
from app.travel_composition import build_travel_container


class CreateTripBody(StrictModel):
    session_id: str = Field(min_length=1,max_length=120)
    request: TripRequest


class PreferenceBody(StrictModel):
    kind: Literal["like","dislike"] = "like"
    statement: str = Field(min_length=2,max_length=120)
    memory_id: str | None = None
    expected_version: int | None = Field(default=None,ge=1)


def build_app():
    @asynccontextmanager
    async def lifespan(api):
        container = await build_travel_container()
        api.state.container = container
        api.state.identity_policy = container.identity_policy
        api.state.session_store = container.session_store
        api.state.session_owner_binding = True
        try:
            yield
        finally:
            await container.shutdown()

    api = FastAPI(title="TripWeaver 旅行规划与动态重排 Agent",version="2.0.0",lifespan=lifespan)

    def container():
        return api.state.container

    async def owner(request):
        return await require_buyer(request,request.headers.get("X-Traveler-ID","demo-traveler"))

    @api.exception_handler(TripConflict)
    @api.exception_handler(MemoryConflict)
    async def conflict(request,error):
        return JSONResponse(status_code=409,content={"detail":str(error)})

    @api.exception_handler(LookupError)
    async def missing(request,error):
        return JSONResponse(status_code=404,content={"detail":str(error)})

    @api.exception_handler(ValueError)
    async def invalid(request,error):
        return JSONResponse(status_code=422,content={"detail":str(error)})

    @api.get("/health")
    @api.get("/travel/status")
    async def status():
        c = container()
        return {"status":"ok","app":"TripWeaver","framework":"langgraph","mode":c.mode,"agent_enabled":c.mode=="live",
                "retrieval":"hybrid" if c.service.catalog.vector_ready else "bm25",
                "retrieval_notice":c.service.catalog.degradation,
                "memory":"semantic" if c.mode=="live" else "explicit_save_lexical_demo",
                "map_configured":bool(c.service.provider.api_key),
                "cities":sorted({p.city for p in c.service.catalog.places}),
                "catalog_size":len(c.service.catalog.places),"catalog_is_demo":any(p.source=="synthetic_demo" for p in c.service.catalog.places)}

    @api.get("/travel/places")
    async def places(request: Request,city: str="杭州",query: str="",indoor: bool=False,family: bool=False,step_free: bool=False):
        await owner(request)
        return await container().service.catalog.search(query,city,indoor=indoor,family=family,step_free=step_free,limit=32)

    @api.post("/travel/trips",status_code=201)
    async def create_trip(body: CreateTripBody,request: Request):
        user = await owner(request)
        await require_session(request,user,body.session_id,create=True)
        return await container().service.create(user,body.session_id,body.request)

    @api.get("/travel/trips")
    async def trips(request: Request):
        return {"trips":await asyncio.to_thread(container().service.store.list,await owner(request))}

    @api.get("/travel/trips/{trip_id}")
    async def get_trip(trip_id: str,request: Request):
        return await asyncio.to_thread(container().service.store.get,await owner(request),trip_id)

    @api.post("/travel/trips/{trip_id}/replan")
    async def replan(trip_id: str,body: ReplanRequest,request: Request):
        return await container().service.replan(await owner(request),trip_id,body)

    @api.get("/travel/trips/{trip_id}/revisions")
    async def revisions(trip_id: str,request: Request):
        return {"revisions":await asyncio.to_thread(container().service.store.revisions,await owner(request),trip_id)}

    @api.get("/travel/trips/{trip_id}/export")
    async def export(trip_id: str,request: Request):
        trip = await asyncio.to_thread(container().service.store.get,await owner(request),trip_id)
        return JSONResponse(content=trip,headers={"Content-Disposition":f'attachment; filename="TripWeaver_{trip_id}.json"'})

    @api.get("/travel/preferences")
    async def preferences(request: Request):
        return {"preferences":[asdict(p) for p in await container().preferences.list_by_buyer(await owner(request))]}

    @api.post("/travel/preferences")
    async def save_preference(body: PreferenceBody,request: Request):
        user = await owner(request)
        value = BuyerPreference(user,body.kind,body.statement)
        if body.memory_id:
            if body.expected_version is None:
                raise ValueError("修改偏好必须提供版本")
            await container().preferences.replace_by_id(user,body.memory_id,body.expected_version,value)
        else:
            await container().preferences.append(value)
        return {"preferences":[asdict(p) for p in await container().preferences.list_by_buyer(user)]}

    @api.delete("/travel/preferences/{memory_id}")
    async def delete_preference(memory_id: str,request: Request,expected_version: int=Query(ge=1)):
        return {"deleted":await container().preferences.delete_by_id(await owner(request),memory_id,expected_version)}

    @api.get("/travel/weather")
    async def weather(request: Request,city: str,travel_date: str):
        await owner(request)
        return await container().service.provider.weather(city,travel_date)

    @api.get("/travel/routes")
    async def route(request: Request,origin: str,destination: str,mode: Literal["walking","driving"]="driving"):
        await owner(request)
        items = container().service.planner.places
        if origin not in items or destination not in items:
            raise ValueError("未知地点")
        return await container().service.provider.route(items[origin],items[destination],mode)

    # 保留上游持久运行、游标续传、取消与原生记忆审批协议，提供旅行命名的别名。
    def live_runtime():
        if container().runtime is None:
            raise HTTPException(503,"演示模式不调用模型；请设置TRIPWEAVER_MODE=live及模型配置后重启")
        return container().runtime

    register_travel_agent_routes(api,live_runtime)

    @api.get("/travel/agent/history")
    async def history(request: Request,session_id: str):
        user = await owner(request)
        await require_session(request,user,session_id,create=True)
        if container().runtime is None:
            return {"messages":[],"runs":[]}
        # 前端通过持久 AG-UI 运行日志恢复，而不是重放模型调用。
        journal = container().runtime.journal
        from app.infrastructure.ag_ui_journal import JournalNotFound
        try:
            return await journal.session(session_id,user)
        except JournalNotFound:
            return {"messages":[],"state":{}}

    dist = Path(__file__).resolve().parents[2]/"frontend/dist"
    if (dist/"assets").exists():
        api.mount("/assets",StaticFiles(directory=dist/"assets"),name="assets")

    @api.get("/")
    async def index():
        if (dist/"index.html").exists():
            return FileResponse(dist/"index.html")
        return {"app":"TripWeaver","message":"前端尚未构建，请执行npm --prefix frontend run build，或使用5173开发服务","docs":"/docs"}

    return api


app = build_app()
