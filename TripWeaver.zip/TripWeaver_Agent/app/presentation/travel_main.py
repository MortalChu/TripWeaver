"""python -m app.presentation.travel_main: one-process local development entry."""
import os
import uvicorn
from app.infrastructure.settings import load_settings


if __name__ == "__main__":
    settings = load_settings()
    uvicorn.run("app.presentation.server:app", host="127.0.0.1", port=settings.port,
                log_level=settings.log_level, workers=1)
