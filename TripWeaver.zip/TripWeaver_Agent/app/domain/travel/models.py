from __future__ import annotations

from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


def minutes(value: str) -> int:
    try:
        hour, minute = map(int, value.split(":"))
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError()
        return hour * 60 + minute
    except (ValueError, AttributeError):
        raise ValueError("时间必须为 HH:MM，且位于当天 00:00–23:59") from None


def clock(value: int) -> str:
    return f"{value // 60:02d}:{value % 60:02d}"


def cents(value: float | Decimal) -> int:
    return int((Decimal(str(value)) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, allow_inf_nan=False)


class Place(StrictModel):
    place_id: str
    name: str
    city: str
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    category: str
    tags: list[str]
    description: str
    indoor: bool
    family_friendly: bool = True
    step_free: bool = True
    duration_minutes: int = Field(ge=15, le=480)
    open_at: str = "09:00"
    close_at: str = "18:00"
    cost_cny: float = Field(ge=0)
    source: Literal["synthetic_demo", "curated"] = "synthetic_demo"
    source_url: str = ""
    verified_at: str | None = None

    @model_validator(mode="after")
    def valid_window(self):
        if minutes(self.close_at) <= minutes(self.open_at):
            raise ValueError("地点开放时间必须晚于开始时间")
        return self

    def document(self) -> str:
        return " ".join([self.name, self.city, self.category, *self.tags, self.description,
                         "室内 雨天" if self.indoor else "户外 自然", "亲子" if self.family_friendly else ""])


class Reservation(StrictModel):
    reservation_id: str = Field(min_length=1, max_length=100)
    place_id: str = Field(min_length=1)
    day: int = Field(ge=1, le=7)
    start: str
    end: str
    total_cost_cny: float = Field(default=0, ge=0)

    @model_validator(mode="after")
    def valid_window(self):
        if minutes(self.end) <= minutes(self.start):
            raise ValueError("预约结束时间必须晚于开始时间")
        return self


class TripRequest(StrictModel):
    city: str = Field(min_length=1, max_length=60)
    start_date: date
    days: int = Field(default=3, ge=1, le=7)
    people: int = Field(default=2, ge=1, le=12)
    budget_cny: float = Field(default=2500, gt=0, le=1000000)
    interests: list[str] = Field(default_factory=lambda: ["文化", "自然"], max_length=12)
    excluded_tags: list[str] = Field(default_factory=list, max_length=20)
    pace: Literal["relaxed", "balanced", "active"] = "balanced"
    family: bool = False
    step_free: bool = False
    transport: Literal["walking", "driving"] = "driving"
    daily_start: str = "09:00"
    daily_end: str = "18:00"
    food_per_person_day_cny: float = Field(default=100, ge=0, le=10000)
    lodging_per_night_cny: float = Field(default=350, ge=0, le=100000)
    intercity_total_cny: float = Field(default=0, ge=0, le=1000000)
    rainy_days: list[int] = Field(default_factory=list, max_length=7)
    reservations: list[Reservation] = Field(default_factory=list, max_length=20)

    @model_validator(mode="after")
    def validate_trip(self):
        if minutes(self.daily_end) <= minutes(self.daily_start):
            raise ValueError("每日结束时间必须晚于开始时间")
        if any(day < 1 or day > self.days for day in self.rainy_days):
            raise ValueError("雨天日期超出本次旅程")
        if any(r.day > self.days for r in self.reservations):
            raise ValueError("预约日期超出本次旅程")
        ids = [r.reservation_id for r in self.reservations]
        if len(set(ids)) != len(ids):
            raise ValueError("预约编号不能重复")
        return self


class ReplanRequest(StrictModel):
    expected_version: int = Field(ge=1)
    reason: Literal["rain", "closure", "budget"]
    affected_day: int = Field(ge=1, le=7)
    closed_place_ids: list[str] = Field(default_factory=list, max_length=30)
    new_budget_cny: float | None = Field(default=None, gt=0, le=1000000)

    @model_validator(mode="after")
    def validate_change(self):
        if self.reason == "closure" and not self.closed_place_ids:
            raise ValueError("关闭场景需要提供地点编号")
        if self.reason == "budget" and self.new_budget_cny is None:
            raise ValueError("预算调整需要提供新预算")
        return self
