"""TripWeaver 装配根：LangGraph 状态图、SQLite checkpoint、长期记忆与持久 SSE。"""
import asyncio
import os
from dataclasses import dataclass, replace
from pathlib import Path

from app.infrastructure.settings import load_settings
from app.infrastructure.travel_catalog import TravelCatalog
from app.infrastructure.travel_store import TripStore
from app.infrastructure.travel_providers import AmapProvider
from app.application.usecases.travel_service import TravelService
from app.infrastructure.persistence.sql.repositories import (create_engine,bootstrap_schema,SqlPreferenceStore,
                                                               SqlSessionStore,SqlConversationStore)
from app.infrastructure.semantic_memory import SemanticPreferenceStore,PreferenceDistiller
from app.infrastructure.travel_memory import DemoPreferenceDistiller,DemoLexicalEmbedder
from app.infrastructure.identity import IdentityPolicy
from app.infrastructure.eventbus import TradeEventBus
from app.infrastructure.persistence.context_evidence import ContextEvidenceStore
from app.infrastructure.throttle import GatewayThrottle
from app.infrastructure.ag_ui_journal import AGUIJournal
from app.presentation.ag_ui_runtime import AGUIRuntime
from app.presentation.travel_ag_ui import TravelAGUIAdapter
from app.infrastructure.tracing import setup_tracing,shutdown_tracing


@dataclass
class TravelContainer:
    settings: object
    mode: str
    service: object
    preferences: object
    engine: object
    session_store: object
    identity_policy: object
    orchestrator: object = None
    runtime: object = None

    async def shutdown(self):
        if self.runtime:
            await self.runtime.shutdown()
        if self.orchestrator:
            await self.orchestrator.close()
        memory_model=getattr(self.preferences.distiller,"model",None)
        if memory_model and hasattr(memory_model,"close"):
            await memory_model.close()
        await self.service.catalog.close()
        await self.engine.dispose()
        await asyncio.to_thread(shutdown_tracing)


async def build_travel_container():
    settings = load_settings()
    mode = os.getenv("TRIPWEAVER_MODE","demo")
    if mode not in {"demo","live"}:
        raise ValueError("TRIPWEAVER_MODE仅支持demo或live")
    root = Path(__file__).resolve().parents[1]
    # 原电商的数据目录和索引不迁移、不打开；旅行数据默认隔离。
    data = Path(os.getenv("DATA_DIR",str(root/"data/runtime")))
    data.mkdir(parents=True,exist_ok=True)
    settings = replace(settings,data_dir=data,database_url=os.getenv("DATABASE_URL") or f"sqlite+aiosqlite:///{data/'tripweaver.db'}",
                       otel_service_name="tripweaver-agent",context_strategy="layered")
    engine = create_engine(settings.database_url)
    await bootstrap_schema(engine)
    sessions = SqlSessionStore(engine)
    catalog = TravelCatalog(Path(os.getenv("TRAVEL_CATALOG_PATH",str(root/"data/travel/places.json"))),settings)
    service = TravelService(catalog,TripStore(data/"trips.db"),AmapProvider(os.getenv("AMAP_API_KEY","")))
    bus = TradeEventBus()
    throttle = GatewayThrottle(max_concurrency=settings.llm_max_concurrency,min_interval_seconds=settings.llm_min_interval_seconds)
    await catalog.startup(live=mode=="live")
    if mode == "live":
        from app.infrastructure.langgraph_model import MemoryChatModel
        from app.infrastructure.embedding.openai_embedding_client import OpenAIEmbeddingClient
        distiller = PreferenceDistiller(MemoryChatModel(settings))
        embedder = OpenAIEmbeddingClient(settings)
        model_id = settings.embedding_model+":"+str(settings.embedding_dim)
    else:
        distiller,embedder,model_id = DemoPreferenceDistiller(),DemoLexicalEmbedder(),"demo-lexical-hash-v1"
    preferences = SemanticPreferenceStore(data/"travel_memory.db",SqlPreferenceStore(engine),distiller,embedder,model_id)
    container = TravelContainer(settings,mode,service,preferences,engine,sessions,IdentityPolicy.from_settings(settings))
    if mode == "live":
        from app.application.agents.langgraph_travel import LangGraphTravelAgent
        setup_tracing(settings)
        evidence = ContextEvidenceStore(data/"context_evidence.db")
        container.orchestrator = await LangGraphTravelAgent.create(settings,service,preferences,sessions,bus,evidence)
        container.runtime = AGUIRuntime(AGUIJournal(data/"ag_ui_runs.db"),container.orchestrator,
                                       adapter_factory=TravelAGUIAdapter)
        await container.runtime.startup()
    return container
