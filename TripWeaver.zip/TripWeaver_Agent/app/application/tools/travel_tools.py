"""旅行工具只接受业务参数，用户与会话身份来自服务端 ContextVar。"""
import asyncio
import json
from typing import Literal

from contextvars import ContextVar
from langchain_core.tools import StructuredTool
from app.infrastructure.context import ShoppingContext
from app.domain.travel.models import TripRequest, ReplanRequest
from app.domain.buyer.preference import BuyerPreference

operation_id = ContextVar("travel_operation_id", default=None)


def build_travel_tools(service,bus,evidence,preferences):
    def identity():
        context = ShoppingContext.current()
        if context is None:
            raise ValueError("缺少旅行会话身份")
        return context.buyer_id,context.shopping_session_id

    async def result(name,operation):
        owner,session = identity()
        try:
            payload = await operation()
            ref = await evidence.save(owner,session,"travel_tool",payload)
            payload = {**payload,"result_ref":ref}
            bus.publish(session,"tool.result",{"tool":name,**payload})
            return payload
        except (ValueError,LookupError) as error:
            return {"error":str(error),"tool":name,"executed":False}

    async def search_places(query: str,city: str,indoor: bool=False,family: bool=False,step_free: bool=False) -> dict:
        """按城市、兴趣、雨天室内、亲子和无障碍条件检索地点；返回数据来源和检索降级状态。"""
        return await result("search_places",lambda:service.catalog.search(query,city,indoor=indoor,family=family,step_free=step_free))

    async def create_trip(city: str,start_date: str,days: int=3,people: int=2,budget_cny: float=2500,
                          interests: list[str] | None=None,pace: Literal["relaxed","balanced","active"]="balanced",
                          family: bool=False,step_free: bool=False,transport: Literal["walking","driving"]="driving",
                          food_per_person_day_cny: float=100,lodging_per_night_cny: float=350,
                          intercity_total_cny: float=0,reservations: list[dict] | None=None) -> dict:
        """生成并保存行程草案，不代订或付款。日期/人数/预算必须由用户明确给出。

        Args:
            city: 目录城市。
            start_date: YYYY-MM-DD 出发日期。
            days: 旅行天数，1至7。
            people: 同行总人数。
            budget_cny: 整组整段旅程总预算，人民币。
            interests: 兴趣词列表。
            pace: relaxed慢节奏、balanced适中、active紧凑。
            family: 是否带孩子。
            step_free: 是否要求无台阶。
            transport: walking步行或driving驾车估算。
            food_per_person_day_cny: 每人每天餐饮估算。
            lodging_per_night_cny: 整组每晚住宿估算。
            intercity_total_cny: 整组往返城市交通估算。
            reservations: 用户明确提供的已确认预约；每项包含reservation_id、place_id、day、start、end、total_cost_cny。时间HH:MM，费用为整组总额。
        """
        owner,session = identity()
        async def execute():
            request = TripRequest(city=city,start_date=start_date,days=days,people=people,budget_cny=budget_cny,
                interests=interests or [],pace=pace,family=family,step_free=step_free,transport=transport,
                food_per_person_day_cny=food_per_person_day_cny,lodging_per_night_cny=lodging_per_night_cny,
                intercity_total_cny=intercity_total_cny,reservations=reservations or [])
            return await service.create(owner,session,request,operation_id=operation_id.get())
        return await result("create_trip",execute)

    async def get_trip(trip_id: str) -> dict:
        """读取用户所属行程的最新版本；修改前必须读取，不猜测版本。"""
        owner,_ = identity()
        return await result("get_trip",lambda:asyncio.to_thread(service.store.get,owner,trip_id))

    async def replan_trip(trip_id: str,expected_version: int,reason: Literal["rain","closure","budget"],
                          affected_day: int,closed_place_ids: list[str] | None=None,new_budget_cny: float | None=None) -> dict:
        """用户请求变更后局部重排。保留锁定预约和其他日期，无法消除的冲突显式返回；只更新草案。"""
        owner,_ = identity()
        async def execute():
            return await service.replan(owner,trip_id,ReplanRequest(expected_version=expected_version,reason=reason,
                affected_day=affected_day,closed_place_ids=closed_place_ids or [],new_budget_cny=new_budget_cny),operation_id=operation_id.get())
        return await result("replan_trip",execute)

    async def check_route(from_place_id: str,to_place_id: str,mode: Literal["walking","driving"]="driving") -> dict:
        """核查两个地点间交通；示例地点只给估算，实时结果来源明确标注。"""
        async def execute():
            places = service.planner.places
            if from_place_id not in places or to_place_id not in places:
                raise ValueError("未知地点编号")
            return await service.provider.route(places[from_place_id],places[to_place_id],mode)
        return await result("check_route",execute)

    async def check_weather(city: str,travel_date: str) -> dict:
        """查询城市在YYYY-MM-DD的天气预报；超出预报范围返回未知，不能据此推测天气。"""
        return await result("check_weather",lambda:service.provider.weather(city,travel_date))

    async def live_place_search(city: str,query: str) -> dict:
        """查询地图地点资料；不代表已知营业时间或价格，不能把查询结果直接当已核验行程。"""
        return await result("live_place_search",lambda:service.provider.search(city,query))

    async def budget_report(trip_id: str) -> dict:
        """返回整组行程费用分解和剩余预算，金额来自代码计算而非模型心算。"""
        owner,_ = identity()
        async def execute():
            trip = await asyncio.to_thread(service.store.get,owner,trip_id)
            return {"trip_id":trip_id,"version":trip["version"],"budget":trip["budget"],"validation":trip["validation"]}
        return await result("budget_report",execute)

    async def travel_evidence_lookup(result_ref: str,offset: int=0) -> dict:
        """按ctx_引用回查本用户本会话的原始工具证据；每页最多6000字符，历史数据不等于实时资料。"""
        owner,session = identity()
        async def execute():
            if offset < 0:
                raise ValueError("offset不能为负数")
            record = await evidence.get(owner,session,result_ref)
            if not record or record["kind"]=="rejected_summary":
                raise LookupError("证据不存在或不可用")
            raw = json.dumps(record["data"],ensure_ascii=False)
            return {"excerpt":raw[offset:offset+6000],"next_offset":offset+6000 if offset+6000<len(raw) else None,
                    "historical":True,"source_ref":result_ref}
        return await result("travel_evidence_lookup",execute)


    async def remember_preference_tool(statement: str, kind: Literal["like","dislike"]="like") -> dict:
        """保存用户明确要求记住的长期旅行偏好；必须先经图 interrupt 审批。"""
        owner,_ = identity()
        await preferences.append(BuyerPreference(owner,kind,statement))
        return {"saved":True,"preferences":[{"memory_id":p.memory_id,"version":p.version,"kind":p.kind,"statement":p.statement}
                for p in await preferences.list_by_buyer(owner)]}

    async def update_preference_tool(memory_id: str,expected_version: int,statement: str,kind: Literal["like","dislike"]="like") -> dict:
        """修改当前 memory_id 对应的长期偏好，校验版本且必须经过图审批。"""
        owner,_ = identity()
        await preferences.replace_by_id(owner,memory_id,expected_version,BuyerPreference(owner,kind,statement))
        return {"updated":True,"memory_id":memory_id}

    async def forget_preference_tool(memory_id: str,expected_version: int) -> dict:
        """删除指定版本的长期偏好，必须经过图审批，拒绝则不执行。"""
        owner,_ = identity()
        return {"deleted":await preferences.delete_by_id(owner,memory_id,expected_version)}

    functions = [search_places,create_trip,get_trip,replan_trip,check_route,check_weather,
                 live_place_search,budget_report,travel_evidence_lookup,remember_preference_tool,
                 update_preference_tool,forget_preference_tool]
    return {fn.__name__:StructuredTool.from_function(coroutine=fn) for fn in functions}
