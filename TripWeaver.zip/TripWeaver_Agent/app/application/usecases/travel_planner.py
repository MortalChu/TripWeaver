"""有约束的贪心排程与局部重排。事实未知不等于已核验，不宣称全局最优。"""
from __future__ import annotations

import copy
import math
from datetime import timedelta

from app.domain.travel.models import Place, TripRequest, ReplanRequest, minutes, clock, cents


def distance_km(a: Place, b: Place) -> float:
    lat1, lat2 = math.radians(a.lat), math.radians(b.lat)
    value = math.sin((lat2-lat1)/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(math.radians(b.lon-a.lon)/2)**2
    return 6371 * 2 * math.asin(min(1, math.sqrt(value)))


def transfer_minutes(a: Place, b: Place, mode: str) -> int:
    # 仅用于初排的直线距离估算，含接驳缓冲，不是地图实时结果。
    return max(10, math.ceil(distance_km(a, b) * 1.4 / (4 if mode == "walking" else 18) * 60) + 10)


class TravelPlanner:
    def __init__(self, places: list[Place]):
        self.places = {p.place_id: p for p in places}

    def eligible(self, p: Place, request: TripRequest, day: int, closed: set[str]) -> bool:
        return (p.city == request.city and p.place_id not in closed
                and (day not in request.rainy_days or p.indoor)
                and (not request.family or p.family_friendly)
                and (not request.step_free or p.step_free)
                and not set(request.excluded_tags).intersection(p.tags))

    def _item(self, p: Place, day: int, start: int, end: int, request: TripRequest, *, reservation=None):
        return {"item_id": f"d{day}_{p.place_id}" if reservation is None else "res_" + reservation.reservation_id,
                "place_id": p.place_id, "name": p.name, "day": day,
                "start": clock(start), "end": clock(end), "indoor": p.indoor,
                "category": p.category, "lat": p.lat, "lon": p.lon,
                "cost_cents": cents(reservation.total_cost_cny) if reservation else cents(p.cost_cny)*request.people,
                "locked": reservation is not None,
                "reservation_id": reservation.reservation_id if reservation else None,
                "source": "user_declared_reservation" if reservation else p.source,
                "verification": "unverified", "note": "用户声明的预约，未向商家核验" if reservation else "目录样例，营业时间与价格需核验"}

    def _fits(self, item, anchors, request):
        p = self.places[item["place_id"]]
        start, end = minutes(item["start"]), minutes(item["end"])
        if start < max(minutes(request.daily_start), minutes(p.open_at)) or end > min(minutes(request.daily_end), minutes(p.close_at)):
            return False
        for other in anchors:
            left, right = minutes(other["start"]), minutes(other["end"])
            travel = transfer_minutes(p, self.places[other["place_id"]], request.transport)
            if not (end + travel <= left or start >= right + travel):
                return False
        return True

    def _base_cost(self, request):
        return (cents(request.food_per_person_day_cny)*request.people*request.days
                + cents(request.lodging_per_night_cny)*max(0,request.days-1)
                + cents(request.intercity_total_cny))

    def _schedule(self, request, anchors, used, *, closed=None, target_days=None, priority=None):
        closed = closed or set()
        selected = copy.deepcopy(anchors)
        limit = {"relaxed": 3, "balanced": 4, "active": 5}[request.pace]
        priorities = {pid: i for i, pid in enumerate(priority or [])}
        for day in range(1, request.days+1):
            if target_days is not None and day not in target_days:
                continue
            candidates = [p for p in self.places.values() if p.place_id not in used and self.eligible(p,request,day,closed)]
            candidates.sort(key=lambda p: (priorities.get(p.place_id, 9999),
                -sum(word in p.document() for word in request.interests), p.cost_cny, p.place_id))
            for p in candidates:
                day_items = [i for i in selected if i["day"] == day]
                if len(day_items) >= limit:
                    break
                # 留出本地交通估算额；最终预算再次完整校验。
                provisional = self._base_cost(request) + sum(i["cost_cents"] for i in selected)
                if request.transport != "walking":
                    provisional += (len(selected)+1)*request.people*1000
                if provisional + cents(p.cost_cny)*request.people > cents(request.budget_cny):
                    continue
                for start in range(max(minutes(request.daily_start), minutes(p.open_at)), minutes(request.daily_end), 15):
                    item = self._item(p,day,start,start+p.duration_minutes,request)
                    if self._fits(item,day_items,request):
                        selected.append(item)
                        used.add(p.place_id)
                        break
        return sorted(selected,key=lambda i:(i["day"],i["start"],i["item_id"]))

    def plan(self, request: TripRequest, *, priority=None):
        if not any(p.city == request.city for p in self.places.values()):
            raise ValueError("当前目录不含该城市，请先导入该城市地点资料")
        anchors = []
        for r in request.reservations:
            p = self.places.get(r.place_id)
            if not p or p.city != request.city:
                raise ValueError("预约地点不在本次城市目录内")
            anchors.append(self._item(p,r.day,minutes(r.start),minutes(r.end),request,reservation=r))
        items = self._schedule(request,anchors,{i["place_id"] for i in anchors},priority=priority)
        return self._document(request,items,changes={"reason":"initial", "changed_item_ids":[]})

    def replan(self, old: dict, change: ReplanRequest):
        request = TripRequest.model_validate(old["request"])
        if change.affected_day > request.days:
            raise ValueError("受影响日期超出行程范围")
        if change.new_budget_cny is not None:
            request.budget_cny = change.new_budget_cny
        if change.reason == "rain":
            request.rainy_days = sorted(set([*request.rainy_days,change.affected_day]))
        closed = set(old.get("closed_place_ids",[])) | set(change.closed_place_ids)
        if any(pid not in self.places for pid in closed):
            raise ValueError("关闭地点编号不存在")
        preserved = []
        removed = []
        for item in old["items"]:
            affected = item["day"] == change.affected_day
            invalid = item["place_id"] in closed or (change.reason == "rain" and not item["indoor"])
            if affected and invalid and not item["locked"]:
                removed.append(item["item_id"])
            else:
                preserved.append(copy.deepcopy(item))
        if change.reason == "budget":
            for item in sorted([i for i in preserved if i["day"] == change.affected_day and not i["locked"]],
                               key=lambda i:i["cost_cents"],reverse=True):
                if self._budget(request,preserved)["total_cents"] <= cents(request.budget_cny):
                    break
                preserved.remove(item)
                removed.append(item["item_id"])
        items = self._schedule(request,preserved,{i["place_id"] for i in preserved},closed=closed,
                               target_days={change.affected_day})
        kept_ids = {i["item_id"] for i in preserved}
        added = [i["item_id"] for i in items if i["item_id"] not in kept_ids]
        doc = self._document(request,items,closed=closed,changes={"reason":change.reason,
            "affected_day":change.affected_day,"removed_item_ids":removed,"added_item_ids":added,
            "preserved_item_ids":sorted(kept_ids),"changed_item_ids":removed+added})
        # 锁定项完整对象比较，禁止模型或计划算法偷偷换时间、费用或地点。
        for item in old["items"]:
            if item["locked"] and item not in doc["items"]:
                raise ValueError("重排违反预约锁定约束")
        return doc

    def _budget(self,request,items):
        parts = {"activities_cents":sum(i["cost_cents"] for i in items),
                 "food_cents":cents(request.food_per_person_day_cny)*request.people*request.days,
                 "lodging_cents":cents(request.lodging_per_night_cny)*max(0,request.days-1),
                 "intercity_cents":cents(request.intercity_total_cny),
                 "local_transport_cents":0 if request.transport == "walking" else len(items)*request.people*1000}
        return {**parts,"total_cents":sum(parts.values()),"limit_cents":cents(request.budget_cny),
                "currency":"CNY","basis":"餐饮按人/天，住宿按整组/晚，本地交通按每站每人10元预留；均为估算"}

    def _document(self,request,items,*,closed=None,changes=None):
        closed = closed or set()
        issues, routes = [], []
        for day in range(1,request.days+1):
            day_items = [i for i in items if i["day"]==day]
            if not day_items:
                issues.append({"code":"EMPTY_DAY","day":day,"message":"可用候选或预算不足，当天未安排活动"})
            for item in day_items:
                p = self.places[item["place_id"]]
                if not self.eligible(p,request,day,closed):
                    issues.append({"code":"LOCKED_CONFLICT" if item["locked"] else "PLACE_CONSTRAINT",
                                   "day":day,"item_id":item["item_id"],"message":"保留的安排与天气、关闭或出行约束冲突，需用户处理"})
                if minutes(item["start"]) < max(minutes(request.daily_start),minutes(p.open_at)) or minutes(item["end"]) > min(minutes(request.daily_end),minutes(p.close_at)):
                    issues.append({"code":"TIME_WINDOW","day":day,"message":"活动超出每日或目录开放时间窗"})
            for previous,current in zip(day_items,day_items[1:]):
                needed = transfer_minutes(self.places[previous["place_id"]],self.places[current["place_id"]],request.transport)
                gap = minutes(current["start"])-minutes(previous["end"])
                routes.append({"day":day,"from":previous["place_id"],"to":current["place_id"],
                               "minutes":needed,"available_minutes":gap,"source":"distance_estimate","verified":False})
                if gap < needed:
                    issues.append({"code":"TRANSFER_CONFLICT","day":day,"message":"活动间隔不足以覆盖交通估算时间"})
        budget = self._budget(request,items)
        if budget["total_cents"] > budget["limit_cents"]:
            issues.append({"code":"OVER_BUDGET","message":"保留预约与基础费用等已超预算，需要调整预算或人工处理预约"})
        return {"request":request.model_dump(mode="json"),"items":items,"routes":routes,"budget":budget,
                "validation":{"feasible":not issues,"issues":issues,"externally_verified":False},
                "days":[{"day":d,"date":str(request.start_date+timedelta(days=d-1))} for d in range(1,request.days+1)],
                "changes":changes or {},"closed_place_ids":sorted(closed),
                "warnings":["目录包含合成演示资料，示例地点、价格和开放时间不代表真实商家。" if any(self.places[i["place_id"]].source == "synthetic_demo" for i in items) else "目录资料需按出行日期核验，收录不代表实时可用。",
                            "交通为直线距离加缓冲估算；行程可行性仅相对于输入与估算值，出发前需核验。",
                            "本系统不代订、不付款；锁定仅记录用户已确认的预约。"]}
