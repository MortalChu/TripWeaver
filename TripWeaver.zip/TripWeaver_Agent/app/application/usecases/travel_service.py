"""旅行应用服务：检索、计划和持久化，所有入口共用同一实现。"""
import asyncio

from app.application.usecases.travel_planner import TravelPlanner
from app.domain.travel.models import TripRequest, ReplanRequest
from app.infrastructure.travel_store import TripConflict


class TravelService:
    def __init__(self,catalog,store,provider):
        self.catalog,self.store,self.provider = catalog,store,provider
        self.planner = TravelPlanner(catalog.places)

    async def create(self,owner,session,request: TripRequest,*,operation_id=None):
        prior=await asyncio.to_thread(self.store.operation,owner,operation_id)
        if prior:
            return prior
        result = await self.catalog.search(" ".join(request.interests),request.city,
                                           family=request.family,step_free=request.step_free,limit=32)
        document = self.planner.plan(request,priority=[p["place_id"] for p in result["places"]])
        document["retrieval"] = {k:v for k,v in result.items() if k != "places"}
        return await asyncio.to_thread(self.store.save,owner,session,document,operation_id=operation_id)

    async def replan(self,owner,trip_id,change: ReplanRequest,*,operation_id=None):
        prior=await asyncio.to_thread(self.store.operation,owner,operation_id)
        if prior:
            return prior
        old = await asyncio.to_thread(self.store.get,owner,trip_id)
        if old["version"] != change.expected_version:
            raise TripConflict("行程已更新，请刷新后重试")
        document = self.planner.replan(old,change)
        return await asyncio.to_thread(self.store.save,owner,old["session_id"],document,
                                       trip_id=trip_id,expected_version=change.expected_version,operation_id=operation_id)

    async def state(self,owner,session):
        trips = await asyncio.to_thread(self.store.list,owner,session)
        # 原编排器的输入注入接口；旅行模式以 trips 标识触发。
        return {"trips":[{"trip_id":t["trip_id"],"version":t["version"],"request":t["request"],
                           "items":t["items"],"budget":t["budget"],"validation":t["validation"]} for t in trips[:2]]}
