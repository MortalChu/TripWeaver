"""HTTP 运行协议 DTO；不依赖具体 Agent 框架。"""
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SubmitIntentInput:
    shopping_session_id: str
    buyer_id: str
    locale: str
    currency: str
    raw_query: str
    selected_skill: Any = None
    confirmations: tuple[dict, ...] = ()


@dataclass(frozen=True)
class SubmitIntentOutput:
    shopping_session_id: str
    final_text: str
    error: str | None = None
    error_code: str | None = None
