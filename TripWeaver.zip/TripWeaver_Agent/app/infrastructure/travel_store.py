"""旅行草案的 SQLite 版本快照；与长期偏好及原交易账本隔离。"""
from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path


class TripConflict(ValueError):
    pass


class TripStore:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS trips (
                    trip_id TEXT PRIMARY KEY, owner TEXT NOT NULL, session_id TEXT NOT NULL,
                    version INTEGER NOT NULL, document TEXT NOT NULL, updated_at TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS trips_owner ON trips(owner, session_id);
                CREATE TABLE IF NOT EXISTS trip_revisions (
                    trip_id TEXT NOT NULL, version INTEGER NOT NULL, document TEXT NOT NULL,
                    PRIMARY KEY(trip_id, version));
                CREATE TABLE IF NOT EXISTS travel_messages (
                    message_id TEXT PRIMARY KEY, owner TEXT NOT NULL, session_id TEXT NOT NULL,
                    role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS travel_operations (
                    owner TEXT NOT NULL, operation_id TEXT NOT NULL, document TEXT NOT NULL,
                    PRIMARY KEY(owner,operation_id));
            """)

    @contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def save(self, owner: str, session_id: str, document: dict, *, trip_id=None, expected_version=None, operation_id=None):
        identifier = trip_id or "trip_" + uuid.uuid4().hex
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            if operation_id:
                prior = db.execute("SELECT document FROM travel_operations WHERE owner=? AND operation_id=?",(owner,operation_id)).fetchone()
                if prior:
                    return json.loads(prior[0])
            previous = db.execute("SELECT * FROM trips WHERE trip_id=?", (identifier,)).fetchone()
            if trip_id and (not previous or previous["owner"] != owner):
                raise LookupError("行程不存在")
            if previous and previous["version"] != expected_version:
                raise TripConflict("行程已更新，请刷新后重试；旧结果没有覆盖新版本")
            version = previous["version"] + 1 if previous else 1
            value = {**document, "trip_id": identifier, "version": version, "session_id": session_id,
                     "updated_at": datetime.now(timezone.utc).isoformat()}
            raw = json.dumps(value, ensure_ascii=False, allow_nan=False)
            db.execute("INSERT OR REPLACE INTO trips VALUES (?,?,?,?,?,?)",
                       (identifier, owner, session_id, version, raw, value["updated_at"]))
            db.execute("INSERT INTO trip_revisions VALUES (?,?,?)", (identifier, version, raw))
            if operation_id:
                db.execute("INSERT INTO travel_operations VALUES (?,?,?)",(owner,operation_id,raw))
            return value

    def operation(self, owner, operation_id):
        if not operation_id:
            return None
        with self.db() as db:
            row=db.execute("SELECT document FROM travel_operations WHERE owner=? AND operation_id=?",(owner,operation_id)).fetchone()
            return json.loads(row[0]) if row else None

    def get(self, owner: str, trip_id: str):
        with self.db() as db:
            row = db.execute("SELECT document FROM trips WHERE trip_id=? AND owner=?", (trip_id, owner)).fetchone()
            if not row:
                raise LookupError("行程不存在")
            return json.loads(row[0])

    def list(self, owner: str, session_id: str | None = None):
        with self.db() as db:
            query = "SELECT document FROM trips WHERE owner=?"
            args = [owner]
            if session_id:
                query += " AND session_id=?"
                args.append(session_id)
            rows = db.execute(query + " ORDER BY updated_at DESC LIMIT 100", args).fetchall()
            return [json.loads(row[0]) for row in rows]

    def revisions(self, owner: str, trip_id: str):
        self.get(owner, trip_id)
        with self.db() as db:
            return [json.loads(row[0]) for row in db.execute(
                "SELECT document FROM trip_revisions WHERE trip_id=? ORDER BY version", (trip_id,))]

    def add_message(self, owner: str, session_id: str, role: str, content: str):
        with self.db() as db:
            db.execute("INSERT INTO travel_messages VALUES (?,?,?,?,?,?)", (
                uuid.uuid4().hex, owner, session_id, role, content, datetime.now(timezone.utc).isoformat()))

    def messages(self, owner: str, session_id: str):
        with self.db() as db:
            return [dict(row) for row in db.execute(
                "SELECT role,content,created_at FROM (SELECT rowid AS position,* FROM travel_messages "
                "WHERE owner=? AND session_id=? ORDER BY rowid DESC LIMIT 200) ORDER BY position",
                (owner, session_id))]
