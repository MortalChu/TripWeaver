"""复用原仓库 BM25 / RRF、embedding、Qdrant 和专用 reranker。"""
from __future__ import annotations

import asyncio
import hashlib
import json
from dataclasses import dataclass, replace
from pathlib import Path

from app.domain.travel.models import Place
from app.infrastructure.retrieval.bm25 import bm25_rank, reciprocal_rank_fusion


@dataclass
class PlaceRecord:
    place: Place

    @property
    def product_id(self):
        # 适配原索引端口的技术字段，不向旅行领域或前端暴露商品概念。
        return self.place.place_id

    def searchable_text(self):
        return self.place.document()


class TravelCatalog:
    def __init__(self, path: Path, settings=None, *, embedder=None, vector_index=None, reranker=None):
        self.path = path
        self.places = [Place.model_validate(row) for row in json.loads(path.read_text(encoding="utf-8"))]
        if len({p.place_id for p in self.places}) != len(self.places):
            raise ValueError("旅行目录地点 ID 重复")
        self.records = [PlaceRecord(p) for p in self.places]
        self.settings = settings
        self.embedder, self.vector_index, self.reranker = embedder, vector_index, reranker
        self.vector_ready = False
        self.degradation = "演示模式使用 BM25 关键词检索，未调用向量模型"

    async def startup(self, *, live=False):
        if not live:
            return
        if self.embedder is None:
            from app.infrastructure.embedding.openai_embedding_client import OpenAIEmbeddingClient
            self.embedder = OpenAIEmbeddingClient(self.settings)
        if self.vector_index is None:
            from app.infrastructure.vector.qdrant_product_index import QdrantProductIndex
            digest = hashlib.sha256((self.path.read_text(encoding="utf-8") + self.settings.embedding_model
                                     + self.settings.embedding_base_url).encode()).hexdigest()[:12]
            self.vector_index = QdrantProductIndex(replace(self.settings,qdrant_collection="tripweaver_places_"+digest))
        try:
            vectors = await asyncio.wait_for(self.embedder.embed_batch([p.document() for p in self.places]),45)
            if len(vectors) != len(self.records) or not vectors or not vectors[0]:
                raise ValueError("向量结果数量不匹配")
            await self.vector_index.ensure_ready(len(vectors[0]))
            await self.vector_index.upsert_products(self.records,vectors)
            self.vector_ready, self.degradation = True, ""
        except Exception as error:
            self.degradation = f"向量服务未就绪（{type(error).__name__}），使用 BM25 降级"
        if self.settings.reranker_base_url and self.settings.reranker_mode == "http":
            from app.infrastructure.rerank.http_reranker import HttpReranker
            self.reranker = HttpReranker(self.settings)

    async def close(self):
        if self.vector_index is not None:
            await self.vector_index.close()

    async def search(self, query: str, city: str, *, indoor=False, family=False, step_free=False, limit=8):
        eligible = [r for r in self.records if r.place.city == city and (not indoor or r.place.indoor)
                    and (not family or r.place.family_friendly) and (not step_free or r.place.step_free)]
        lexical = bm25_rank(query,eligible) if query.strip() else [(1.,r) for r in eligible]
        ranking, strategy, warnings = lexical, "bm25", []
        if self.degradation:
            warnings.append(self.degradation)
        if self.vector_ready:
            try:
                vector = await asyncio.wait_for(self.embedder.embed(query or city),15)
                hits = await self.vector_index.search_filtered(vector,max(32,limit),product_ids=[r.product_id for r in eligible])
                lookup = {r.product_id:r for r in eligible}
                dense = [(h.score,lookup[h.product_id]) for h in hits if h.product_id in lookup]
                ranking = reciprocal_rank_fusion(lexical,dense)
                strategy = "bm25_dense_rrf"
            except Exception as error:
                warnings.append(f"本轮向量查询失败（{type(error).__name__}），已降级 BM25")
        ranking = ranking[:32]
        reranked = False
        if ranking and self.reranker:
            try:
                scores = await self.reranker.rerank(query,[r.searchable_text() for _,r in ranking])
                if len(scores) != len(ranking):
                    raise ValueError("精排返回数量不完整")
                ranking = sorted(zip(scores,[r for _,r in ranking]),key=lambda row:-row[0])
                reranked = True
            except Exception as error:
                warnings.append(f"精排不可用（{type(error).__name__}），保留召回顺序")
        return {"places":[{**r.place.model_dump(),"relevance":round(score,6)} for score,r in ranking[:limit]],
                "recall_strategy":strategy,"rerank_applied":reranked,"warnings":warnings,
                "query":query,"city":city,"source":"travel_catalog","verified":False}
