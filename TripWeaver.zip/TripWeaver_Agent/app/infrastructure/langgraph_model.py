"""LangChain ChatOpenAI 适配兼容网关；图负责循环，客户端只负责模型调用。"""
from langchain_openai import ChatOpenAI
from app.infrastructure.throttle import GatewayThrottle
import asyncio
import json


def create_travel_model(settings, role="supervisor"):
    return ChatOpenAI(model=settings.llm_model, api_key=settings.llm_api_key,
                      base_url=settings.llm_base_url, temperature=0,
                      timeout=60, max_retries=settings.llm_max_retries,
                      max_tokens=2048, stream_usage=True)


class MemoryChatModel:
    """审批后的偏好提炼复用本轮模型预算与并发闸门；表单保存独立限流。"""
    def __init__(self,settings):
        self.model=create_travel_model(settings,"memory")
        self.throttle=GatewayThrottle(settings.llm_max_concurrency,settings.llm_min_interval_seconds)

    async def ainvoke(self,messages,**kwargs):
        from app.application.agents.langgraph_travel import CURRENT,estimate
        turn=CURRENT.get(None)
        reserve=estimate([m.model_dump() for m in messages])+1200
        if turn and not await turn.reserve(reserve):
            raise ValueError("本轮模型预算不足，未执行偏好提炼")
        result=None
        try:
            throttle=(turn.throttle if turn and turn.throttle else self.throttle)
            async with throttle.slot():
                result=await self.model.ainvoke(messages,**kwargs)
            return result
        finally:
            if turn:
                usage=result.usage_metadata if result is not None else None
                await turn.settle(reserve,usage.get("total_tokens") if usage else None)

    async def close(self):
        for name in ("root_async_client",):
            client=getattr(self.model,name,None)
            if client:
                await client.close()
        client=getattr(self.model,"root_client",None)
        if client:
            client.close()
