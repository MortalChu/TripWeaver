"""演示模式只保存用户手动确认的偏好；词项指纹明确不作为语义模型。"""
import hashlib
import re
from app.infrastructure.retrieval.bm25 import terms


class DemoPreferenceDistiller:
    async def extract(self,preference,existing=()):
        statement = preference.statement.strip()
        if re.search(r"这次|本次|明天|后天|预算|预约号|身份证|电话|密钥|忽略指令|20\d{2}[-年/]",statement):
            return []
        conflicts = [p.memory_id for p in existing if p.statement == statement and p.kind != preference.kind]
        return [{"kind":preference.kind,"statement":statement,"conflicts":conflicts}]


class DemoLexicalEmbedder:
    """用于离线偏好匹配的固定词项哈希，不参与地点向量检索。"""
    async def embed(self,text):
        vector = [0.0]*256
        for word in terms(text) or [text]:
            vector[int.from_bytes(hashlib.sha256(word.encode()).digest()[:4],"little")%256] += 1
        return vector

    async def embed_batch(self,texts):
        return [await self.embed(text) for text in texts]
