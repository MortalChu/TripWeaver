"""只读地图适配器。缺少密钥/供应商失败时明确返回未核验，绝不伪造实时结果。"""
from __future__ import annotations

import asyncio
from datetime import date
import httpx

from app.application.usecases.travel_planner import transfer_minutes


class AmapProvider:
    BASE_URL = "https://restapi.amap.com/v3"

    def __init__(self, api_key="", *, transport=None):
        self.api_key, self.transport = api_key, transport

    async def _get(self,path,params):
        if not self.api_key:
            return {"verified":False,"error":"未配置 AMAP_API_KEY，未查询实时地图服务"}
        for attempt in range(2):
            try:
                async with httpx.AsyncClient(timeout=8,transport=self.transport,follow_redirects=False) as client:
                    response = await client.get(self.BASE_URL+path,params={**params,"key":self.api_key})
                    response.raise_for_status()
                    data = response.json()
                if not isinstance(data, dict):
                    raise ValueError("invalid response")
                if data.get("status") != "1":
                    return {"verified":False,"error":"地图供应商拒绝请求，请检查密钥权限或配额"}
                return {"verified":True,"data":data,"source":"amap"}
            except (httpx.HTTPError,ValueError):
                if attempt == 0:
                    await asyncio.sleep(.2)
        return {"verified":False,"error":"地图服务超时或响应无效，未取得可核验结果"}

    async def weather(self,city,travel_date):
        date.fromisoformat(travel_date)
        # 天气接口使用行政区划编码，地点检索接口才直接接受城市名称。
        codes = {"杭州":"330100","杭州市":"330100","成都":"510100","成都市":"510100",
                 "上海":"310000","上海市":"310000"}
        code = codes.get(city, city if len(city) == 6 and city.isdigit() else None)
        if code is None:
            lookup = await self._get("/geocode/geo", {"address":city,"city":city})
            if not lookup.get("verified"):
                return lookup
            geocodes = lookup["data"].get("geocodes", [])
            code = next((row.get("adcode") for row in geocodes if row.get("adcode")), None)
            if not code:
                return {"verified":False,"source":"amap","error":"无法确定天气查询所需的城市编码"}
        result = await self._get("/weather/weatherInfo",{"city":code,"extensions":"all"})
        if not result.get("verified"):
            return result
        forecasts = result["data"].get("forecasts",[])
        matches = [cast for f in forecasts for cast in f.get("casts",[]) if cast.get("date")==travel_date]
        if not matches:
            return {"verified":False,"source":"amap","error":"目标日期不在供应商当前预报范围内"}
        return {"verified":True,"source":"amap","date":travel_date,"forecast":matches[0],
                "notice":"天气预报可能变化；查询不会自动改写行程"}

    async def route(self,a,b,mode="driving"):
        estimate = {"minutes":transfer_minutes(a,b,mode),"verified":False,"source":"distance_estimate"}
        if a.source == "synthetic_demo" or b.source == "synthetic_demo":
            return {**estimate,"notice":"演示地点不用于真实导航，返回含缓冲的距离估算"}
        result = await self._get("/direction/"+mode,{"origin":f"{a.lon},{a.lat}","destination":f"{b.lon},{b.lat}"})
        if not result.get("verified"):
            return {**estimate,"notice":result["error"]}
        paths = result["data"].get("route",{}).get("paths",[])
        if not paths:
            return {**estimate,"notice":"供应商未返回可用路径"}
        try:
            seconds = int(paths[0]["duration"])
            if seconds < 0:
                raise ValueError()
        except (KeyError,TypeError,ValueError):
            return {**estimate,"notice":"供应商路径时长无效"}
        return {"minutes":(seconds+59)//60,"distance_meters":paths[0].get("distance"),
                "verified":True,"source":"amap","notice":"供应商当前估算，非到达保证"}

    async def search(self,city,query):
        result = await self._get("/place/text",{"city":city,"keywords":query,"citylimit":"true","offset":10,"extensions":"base"})
        if not result.get("verified"):
            return result
        return {"verified":True,"source":"amap","places":[{k:p.get(k) for k in
            ("id","name","type","address","location","adname")} for p in result["data"].get("pois",[])],
            "notice":"仅核验地点资料，不代表价格、开放时间或预约可用；导入完整目录后方可排程"}
