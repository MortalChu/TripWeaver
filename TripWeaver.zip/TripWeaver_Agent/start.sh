#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
    echo 'Project environment not found. Run sh setup.sh first.' >&2
    exit 1
fi
exec .venv/bin/python -m app.presentation.travel_main
