import {useEffect,useRef,useState} from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {headers,money,nextDate,readEvents,request,traveler} from "./travel/api";
import type {Approval,Item,Message,Place,Preference,Status,Trip} from "./travel/types";

function Glyph({name}:{name:string}) {return <span aria-hidden="true" className="glyph">{({route:"↗",pin:"⌖",lock:"▣",sun:"☀",rain:"☂",leaf:"❋",arrow:"→",chat:"✦",clock:"◷",plus:"＋"} as Record<string,string>)[name]||"·"}</span>}
function MapSketch({items}:{items:Item[]}) {
  const pts=items.length?items:[];
  const minLat=Math.min(...pts.map(p=>p.lat)),maxLat=Math.max(...pts.map(p=>p.lat));
  const minLon=Math.min(...pts.map(p=>p.lon)),maxLon=Math.max(...pts.map(p=>p.lon));
  const positions=pts.map(p=>({x:45+(p.lon-minLon)/Math.max(.01,maxLon-minLon)*260,y:145-(p.lat-minLat)/Math.max(.01,maxLat-minLat)*100}));
  return <div className="map-sketch"><svg viewBox="0 0 360 185" role="img" aria-label="当天地点相对位置示意，非实际导航地图">
    <rect width="360" height="185" fill="#e8eee4"/><path d="M-10 130 Q100 20 180 100 T390 50" fill="none" stroke="#c5dcd5" strokeWidth="35"/>
    {[20,65,110,155].map(y=><path key={y} d={`M0 ${y} L360 ${y-10}`} stroke="#f8faf5" strokeWidth="9"/>)}
    {[30,105,185,265,335].map(x=><path key={x} d={`M${x} 0 L${x-30} 185`} stroke="#f8faf5" strokeWidth="7"/>)}
    <polyline points={positions.map(p=>`${p.x},${p.y}`).join(" ")} fill="none" stroke="#347463" strokeWidth="2" strokeDasharray="5 5"/>
    {positions.map((p,i)=><g key={i}><circle cx={p.x} cy={p.y} r="11" fill="#245346"/><text x={p.x} y={p.y+4} textAnchor="middle" fill="white" fontSize="10">{i+1}</text></g>)}
  </svg><small>地点相对位置 · 非导航地图</small></div>
}

function AgentChat({status,session,changed}:{status:Status|null;session:string;changed:()=>void}) {
  const [messages,setMessages]=useState<Message[]>([]),[input,setInput]=useState(""),[busy,setBusy]=useState(false);
  const [error,setError]=useState(""),[events,setEvents]=useState<string[]>([]),[approvals,setApprovals]=useState<Approval[]>([]);
  const run=useRef("");const box=useRef<HTMLDivElement>(null);const stream=useRef<AbortController|null>(null);
  function consume(event:Record<string,unknown>){
    if(event.type==="TEXT_MESSAGE_CONTENT")setMessages(old=>{const id=String(event.messageId),delta=String(event.delta||"");
      return old.some(m=>m.id===id)?old.map(m=>m.id===id?{...m,content:m.content+delta}:m):[...old,{id,role:"assistant",content:delta}]});
    if(event.type==="TOOL_CALL_START")setEvents(old=>[...old.slice(-7),`调用 ${String(event.toolCallName)}`]);
    if(event.type==="CUSTOM"&&event.name==="agent.dispatch")setEvents(old=>[...old.slice(-7),"派发专家子任务"]);
    if(event.type==="STATE_SNAPSHOT"){const snapshot=event.snapshot as {toolApprovals?:Approval[]};setApprovals(snapshot.toolApprovals||[])}
    if(event.type==="RUN_ERROR")setError(String(event.message));
  }
  useEffect(()=>{setMessages([]);setApprovals([]);setEvents([]);setError("");
    if(!status?.agent_enabled)return;
    let active=true;setBusy(false);
    request<{messages?:Message[];state?:{toolApprovals?:Approval[]};run?:{status:string;runId:string;cursor:number}}>(`/travel/agent/history?session_id=${encodeURIComponent(session)}`)
      .then(async data=>{if(!active)return;setMessages(data.messages||[]);setApprovals(data.state?.toolApprovals||[]);
        if(data.run?.status==="running"){
          run.current=data.run.runId;setBusy(true);const controller=new AbortController();stream.current=controller;
          try{const response=await fetch(`/travel/agent/runs/${encodeURIComponent(data.run.runId)}/events?buyer_id=${encodeURIComponent(traveler)}&after=${data.run.cursor}`,{headers:headers(),signal:controller.signal});
            await readEvents(response,event=>{if(active)consume(event)});if(active)changed();
          }finally{if(active)setBusy(false)}
        }
      }).catch(e=>{if(active&&e.name!=="AbortError")setError(e.message)});
    return()=>{active=false;stream.current?.abort()};
  },[session,status?.agent_enabled]);
  useEffect(()=>{box.current?.scrollTo({top:box.current.scrollHeight,behavior:"smooth"})},[messages,events]);
  async function send(text=input,resume?:{id:string;approved:boolean}) {
    if(!text.trim()||busy)return;setInput("");setError("");setBusy(true);setEvents([]);
    const user={id:crypto.randomUUID(),role:"user",content:text};setMessages(old=>[...old,user]);
    run.current=crypto.randomUUID();const controller=new AbortController();stream.current=controller;
    try {const response=await fetch("/travel/agent/run",{method:"POST",headers:headers(),signal:controller.signal,body:JSON.stringify({
      threadId:session,runId:run.current,messages:[user],tools:[],context:[],state:{},forwardedProps:{buyerId:traveler,locale:"zh-CN",currency:"CNY"},
      ...(resume?{resume:[{interruptId:resume.id,status:"resolved",payload:{approved:resume.approved}}]}:{})})});
      setApprovals([]);
      await readEvents(response,event=>{if(!controller.signal.aborted)consume(event)});if(!controller.signal.aborted)changed();
    }catch(e){if(!controller.signal.aborted)setError((e as Error).message)}finally{if(!controller.signal.aborted)setBusy(false)}
  }
  async function stop(){try{await request(`/travel/agent/runs/${run.current}/cancel?buyer_id=${encodeURIComponent(traveler)}`,{method:"POST"})}catch(e){setError((e as Error).message)}}
  return <section className="agent-chat"><div className="section-top"><div><span className="eyebrow">YOUR TRAVEL COPILOT</span><h2>和旅行助手聊聊</h2></div><span className="pill">{status?.agent_enabled?"模型已启用":"演示模式"}</span></div>
    {!status?.agent_enabled?<div className="chat-intro"><Glyph name="chat"/><h3>先体验一份真正可调整的行程</h3><p>当前无需密钥，即可使用行程表单、预约锁定、费用核算和局部重排。</p><p>自由对话需在 .env 中配置模型并切换至 live 模式，重启后启用。</p></div>:<>
    <div ref={box} className="chat-messages">{!messages.length&&<p className="muted">例如：帮我核对当前行程第二天的交通衔接，保留所有已确认预约。</p>}
      {messages.map(m=><div className={`message ${m.role}`} key={m.id}><span>{m.role==="user"?"你":"TripWeaver"}</span><ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown></div>)}
      {events.length>0&&<div className="tool-events">{events.map((e,i)=><small key={i}>↳ {e}</small>)}</div>}
    </div>
    {approvals.map(a=><div className="approval" key={a.id}><strong>{a.label}</strong><p>{typeof a.arguments==="string"?a.arguments:JSON.stringify(a.arguments)}</p><button disabled={busy} onClick={()=>void send("拒绝这次长期记忆操作",{id:a.id,approved:false})}>拒绝</button><button disabled={busy} onClick={()=>void send("批准这次长期记忆操作",{id:a.id,approved:true})}>批准</button></div>)}
    {error&&<p className="error" role="alert">{error}</p>}
    <form className="chat-input" onSubmit={e=>{e.preventDefault();void send()}}><textarea aria-label="对话内容" placeholder="告诉我你的想法，或继续调整行程…" value={input} onChange={e=>setInput(e.target.value)} disabled={busy}/>{busy?<button type="button" onClick={()=>void stop()}>停止</button>:<button className="primary" disabled={!input.trim()}>发送 ↗</button>}</form></>}
  </section>
}

export default function TripWeaver() {
  const [status,setStatus]=useState<Status|null>(null),[trips,setTrips]=useState<Trip[]>([]),[trip,setTrip]=useState<Trip|null>(null);
  const [places,setPlaces]=useState<Place[]>([]),[preferences,setPreferences]=useState<Preference[]>([]);
  const [tab,setTab]=useState("plan"),[day,setDay]=useState(1),[busy,setBusy]=useState(false),[error,setError]=useState("");
  const [city,setCity]=useState("杭州"),[date,setDate]=useState(nextDate()),[days,setDays]=useState(3),[people,setPeople]=useState(2),[budget,setBudget]=useState(2500);
  const [interests,setInterests]=useState(["文化","自然"]),[pace,setPace]=useState("balanced"),[family,setFamily]=useState(false),[stepFree,setStepFree]=useState(false);
  const [food,setFood]=useState(100),[hotel,setHotel]=useState(350),[intercity,setIntercity]=useState(0),[transport,setTransport]=useState("driving");
  const [withLock,setWithLock]=useState(false),[lockedPlace,setLockedPlace]=useState(""),[lockDay,setLockDay]=useState(1),[lockStart,setLockStart]=useState("10:00"),[lockEnd,setLockEnd]=useState("11:30"),[lockCost,setLockCost]=useState(0);
  const [change,setChange]=useState("rain"),[closed,setClosed]=useState(""),[newBudget,setNewBudget]=useState(1800);
  const [prefText,setPrefText]=useState(""),[prefKind,setPrefKind]=useState("like"),[editing,setEditing]=useState<Preference|null>(null);
  const [revisions,setRevisions]=useState<Trip[]>([]),[session,setSession]=useState(()=>localStorage.getItem("tripweaver-session")||crypto.randomUUID());
  async function refresh(selectLatest=false) {const result=await request<{trips:Trip[]}>("/travel/trips");setTrips(result.trips);if(selectLatest&&result.trips[0]){setTrip(result.trips[0]);setSession(result.trips[0].session_id)}}
  async function refreshPrefs(){setPreferences((await request<{preferences:Preference[]}>("/travel/preferences")).preferences)}
  useEffect(()=>{Promise.all([request<Status>("/travel/status").then(setStatus),refresh(true),refreshPrefs()]).catch(e=>setError(e.message))},[]);
  useEffect(()=>{localStorage.setItem("tripweaver-session",session)},[session]);
  useEffect(()=>{let active=true;request<{places:Place[]}>(`/travel/places?city=${encodeURIComponent(city)}`).then(data=>{if(active){setPlaces(data.places);setLockedPlace(data.places[0]?.place_id||"")}}).catch(e=>setError(e.message));return()=>{active=false}},[city]);
  useEffect(()=>{if(trip){setClosed(trip.items.find(i=>i.day===day&&!i.locked)?.place_id||"");request<{revisions:Trip[]}>(`/travel/trips/${trip.trip_id}/revisions`).then(data=>setRevisions(data.revisions)).catch(e=>setError(e.message))}},[trip,day]);
  async function action(work:()=>Promise<void>){if(busy)return;setBusy(true);setError("");try{await work()}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
  async function create(){await action(async()=>{const id=crypto.randomUUID();const result=await request<Trip>("/travel/trips",{method:"POST",body:JSON.stringify({session_id:id,request:{city,start_date:date,days,people,budget_cny:budget,interests,pace,family,step_free:stepFree,transport,
      food_per_person_day_cny:food,lodging_per_night_cny:hotel,intercity_total_cny:intercity,reservations:withLock?[{reservation_id:crypto.randomUUID(),place_id:lockedPlace,day:lockDay,start:lockStart,end:lockEnd,total_cost_cny:lockCost}]:[]}})});
      setTrip(result);setSession(id);setDay(1);await refresh();})}
  async function replan(){if(!trip)return;await action(async()=>{const result=await request<Trip>(`/travel/trips/${trip.trip_id}/replan`,{method:"POST",body:JSON.stringify({expected_version:trip.version,reason:change,affected_day:day,closed_place_ids:change==="closure"?[closed]:[],new_budget_cny:change==="budget"?newBudget:null})});setTrip(result);await refresh()})}
  async function savePref(){await action(async()=>{await request("/travel/preferences",{method:"POST",body:JSON.stringify({kind:prefKind,statement:prefText,...(editing?{memory_id:editing.memory_id,expected_version:editing.version}:{})})});setPrefText("");setEditing(null);await refreshPrefs()})}
  async function exportTrip(){if(!trip)return;const data=await request<Trip>(`/travel/trips/${trip.trip_id}/export`);const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));const a=document.createElement("a");a.href=url;a.download=`TripWeaver_${trip.request.city}_v${trip.version}.json`;a.click();URL.revokeObjectURL(url)}
  const items=trip?.items.filter(i=>i.day===day)||[];const total=Number(trip?.budget.total_cents||0),limit=Number(trip?.budget.limit_cents||1);
  return <div className="tw-app"><header className="topbar"><a className="brand" href="/"><span className="brand-mark">↗</span>TripWeaver<span className="brand-sub">把旅途，安排得刚刚好</span></a><div className="top-right"><span className="status-dot"/>{status?.mode==="live"?"在线 Agent":"离线演示"}<span className="top-separator"/>自由行工作台</div></header>
    <div className="app-layout"><aside className="sidebar"><div className="side-label">WORKSPACE</div><nav>{[["plan","route","我的行程"],["chat","chat","旅行助手"],["preferences","leaf","出行偏好"]].map(([id,icon,label])=><button key={id} className={tab===id?"active":""} onClick={()=>setTab(id)}><Glyph name={icon}/>{label}<span>›</span></button>)}</nav>
      <div className="side-label history-label">最近的旅程 <span>{trips.length}</span></div><div className="trip-history">{trips.slice(0,15).map(t=><button className={trip?.trip_id===t.trip_id?"selected":""} key={t.trip_id} onClick={()=>{setTrip(t);setSession(t.session_id);setDay(1);setTab("plan")}}><span className="history-city">{t.request.city.slice(0,1)}</span><span><strong>{t.request.city} · {t.request.days} 日</strong><small>{t.request.start_date} / v{t.version}</small></span></button>)}{!trips.length&&<p className="muted">你的第一段旅程<br/>从这里开始。</p>}</div>
      <div className="sidebar-note"><Glyph name="leaf"/><strong>留一点空间给惊喜</strong><p>计划可以改变。<br/>已确认的安排，好好保留。</p></div></aside>
    <main><section className="hero"><div><span className="eyebrow">LESS PLANNING. MORE EXPLORING.</span><h1>下一站，<em>从容出发。</em></h1><p>把想去的地方串成旅程，也为变化留好余地。</p></div><div className="hero-art" aria-hidden="true"><div className="sun"/><svg viewBox="0 0 280 130"><path d="M0 130 L85 24 L158 130" fill="#94aaa0"/><path d="M80 130 L183 10 L280 130" fill="#527c6c"/><path d="M163 34 L183 10 L208 41 L184 33Z" fill="#f7f5eb"/><path d="M145 128 Q210 100 185 88 T231 66" fill="none" stroke="#d9cda6" strokeWidth="8"/></svg><span>MAKE ROOM FOR THE UNEXPECTED</span></div></section>
      {status?.catalog_is_demo&&<div className="demo-banner"><span>演示数据</span>内置 {status.catalog_size} 个合成地点。价格、开放时间与交通估算用于功能体验，不作为真实出行依据。</div>}
      {error&&<div className="error" role="alert">{error}<button onClick={()=>setError("")}>关闭</button></div>}
      {tab==="chat"?<AgentChat status={status} session={session} changed={()=>{void refresh(true);void refreshPrefs()}}/>:tab==="preferences"?<section className="preference-panel"><span className="eyebrow">YOUR WAY TO TRAVEL</span><h2>记住你的出行偏好</h2><p className="muted">只保存你明确确认的长期偏好。本次日期、预算与预约单独保留在行程中。</p>
        <form className="preference-form" onSubmit={e=>{e.preventDefault();void savePref()}}><select aria-label="偏好类型" value={prefKind} onChange={e=>setPrefKind(e.target.value)}><option value="like">喜欢</option><option value="dislike">避免</option></select><input aria-label="长期偏好" maxLength={120} value={prefText} onChange={e=>setPrefText(e.target.value)} placeholder="例如：偏好安静的住宿和慢节奏行程"/><button className="primary" disabled={busy||!prefText.trim()}>{editing?"更新偏好":"确认保存"}</button>{editing&&<button type="button" onClick={()=>{setEditing(null);setPrefText("")}}>取消编辑</button>}</form>
        <div className="preference-list">{preferences.map(p=><article key={p.memory_id}><span className="pill">{p.kind==="like"?"喜欢":"避免"}</span><p>{p.statement}</p><small>v{p.version}</small><button onClick={()=>{setEditing(p);setPrefText(p.statement);setPrefKind(p.kind)}}>编辑</button><button disabled={busy} onClick={()=>void action(async()=>{await request(`/travel/preferences/${p.memory_id}?expected_version=${p.version}`,{method:"DELETE"});await refreshPrefs()})}>删除</button></article>)}{!preferences.length&&<div className="empty-preferences">还没有长期偏好，保存后可以跨会话使用。</div>}</div>
        <p className="footnote">{status?.mode==="demo"?"演示模式：手动保存与词项匹配；在线模式使用模型提炼及语义召回。":"在线模式：模型提炼稳定事实，事实与向量在 SQLite 中一起保存。"}</p></section>:<div className="planner-grid">
      <section className="planning-form"><div className="section-top"><div><span className="eyebrow">01 / THE STARTING POINT</span><h2>说说你的旅行</h2></div><Glyph name="pin"/></div>
        <form onSubmit={e=>{e.preventDefault();void create()}}><label>目的地<select value={city} onChange={e=>setCity(e.target.value)}>{(status?.cities||["杭州","成都","上海"]).map(c=><option key={c}>{c}</option>)}</select></label>
          <div className="field-row"><label>出发日期<input type="date" required value={date} onChange={e=>setDate(e.target.value)}/></label><label>旅行天数<input type="number" min={1} max={7} value={days} onChange={e=>setDays(Number(e.target.value))}/></label></div>
          <div className="field-row"><label>同行人数<input type="number" min={1} max={12} value={people} onChange={e=>setPeople(Number(e.target.value))}/></label><label>整组总预算 / 元<input type="number" min={1} max={1000000} value={budget} onChange={e=>setBudget(Number(e.target.value))}/></label></div>
          <label>旅行兴趣</label><div className="interest-chips">{["文化","自然","美食","艺术","亲子","休闲"].map(i=><button type="button" className={interests.includes(i)?"chosen":""} key={i} onClick={()=>setInterests(old=>old.includes(i)?old.filter(x=>x!==i):[...old,i])}>{i}</button>)}</div>
          <div className="field-row"><label>行程节奏<select value={pace} onChange={e=>setPace(e.target.value)}><option value="relaxed">慢一点 · 每天最多 3 站</option><option value="balanced">刚刚好 · 每天最多 4 站</option><option value="active">丰富些 · 每天最多 5 站</option></select></label><label>交通方式<select value={transport} onChange={e=>setTransport(e.target.value)}><option value="driving">驾车估算</option><option value="walking">步行估算</option></select></label></div>
          <div className="checks"><label><input type="checkbox" checked={family} onChange={e=>setFamily(e.target.checked)}/>带孩子</label><label><input type="checkbox" checked={stepFree} onChange={e=>setStepFree(e.target.checked)}/>无台阶需求</label></div>
          <details><summary>费用估算口径</summary><div className="field-row"><label>餐饮 / 人 / 天<input type="number" min={0} value={food} onChange={e=>setFood(Number(e.target.value))}/></label><label>住宿 / 整组 / 晚<input type="number" min={0} value={hotel} onChange={e=>setHotel(Number(e.target.value))}/></label></div><label>城际往返 / 整组<input type="number" min={0} value={intercity} onChange={e=>setIntercity(Number(e.target.value))}/></label><small>驾车模式每站每人预留 10 元本地交通，步行不计车费。</small></details>
          <div className="reservation"><label className="check-title"><input type="checkbox" checked={withLock} onChange={e=>setWithLock(e.target.checked)}/><Glyph name="lock"/>已有预约，排程时保留</label>{withLock&&<div className="reservation-fields"><label>预约地点<select value={lockedPlace} onChange={e=>setLockedPlace(e.target.value)}>{places.map(p=><option key={p.place_id} value={p.place_id}>{p.name}</option>)}</select></label><div className="field-row"><label>第几天<input type="number" min={1} max={days} value={lockDay} onChange={e=>setLockDay(Number(e.target.value))}/></label><label>已知费用 / 整组<input type="number" min={0} value={lockCost} onChange={e=>setLockCost(Number(e.target.value))}/></label></div><div className="field-row"><label>开始<input type="time" required value={lockStart} onChange={e=>setLockStart(e.target.value)}/></label><label>结束<input type="time" required value={lockEnd} onChange={e=>setLockEnd(e.target.value)}/></label></div><small>仅记录你声明的预约，不代表已向商家查询或下单。</small></div>}</div>
          <button className="primary generate" disabled={busy}>{busy?"正在计算…":"生成我的行程"}<Glyph name="arrow"/></button></form>
      </section>
      <section className="itinerary-area">{trip?<><div className="section-top itinerary-heading"><div><span className="eyebrow">02 / YOUR JOURNEY</span><h2>{trip.request.city}，{trip.request.days} 天好时光 <span className="version">v{trip.version}</span></h2><p>{trip.request.start_date} 出发 · {trip.request.people} 人同行 · {trip.items.length} 个安排</p></div><button className="subtle" onClick={()=>void exportTrip()}>导出行程 ↗</button></div>
      <div className="plan-metrics"><div><small>行程估算</small><strong>{money(total)}</strong></div><div><small>预算余额</small><strong className={total>limit?"red":""}>{money(limit-total)}</strong></div><div><small>已锁定预约</small><strong>{trip.items.filter(i=>i.locked).length}<span> 个</span></strong></div><div><small>约束检查</small><strong className={trip.validation.feasible?"green":"red"}>{trip.validation.feasible?"通过":"需处理"}</strong></div></div>
      {!trip.validation.feasible&&<div className="issue-list" role="status"><strong>以下条件仍需处理</strong>{trip.validation.issues.map((issue,i)=><p key={i}>{issue.day?`第${issue.day}天：`:""}{issue.message}</p>)}</div>}
      <div className="day-tabs">{trip.days.map(d=><button className={day===d.day?"selected":""} key={d.day} onClick={()=>setDay(d.day)}>DAY {String(d.day).padStart(2,"0")}<small>{d.date.slice(5).replace("-"," / ")}</small></button>)}</div>
      <div className="day-layout"><div className="timeline">{items.map((item,i)=><article className="stop" key={item.item_id}><div className="stop-time">{item.start}<small>{item.end}</small></div><div className="stop-track"><span>{i+1}</span></div><div className="stop-card"><div className="stop-tags"><span>{item.category}</span><span>{item.indoor?"室内":"户外"}</span>{item.locked&&<span className="locked"><Glyph name="lock"/>预约锁定</span>}</div><h3>{item.name}</h3><p>{item.note}</p><div className="stop-bottom"><span>{money(item.cost_cents)} / 整组</span><small>{item.place_id}</small></div></div></article>)}{!items.length&&<p className="muted">当天暂无符合条件的安排，请检查预算与约束。</p>}</div>
      <div className="day-side"><MapSketch items={items}/><div className="budget-card"><h3>费用分布 <small>整段旅程</small></h3>{[["activities_cents","活动与预约"],["food_cents","餐饮"],["lodging_cents","住宿"],["local_transport_cents","本地交通"],["intercity_cents","城际交通"]].map(([key,label])=><div className="budget-row" key={key}><div><span>{label}</span><strong>{money(trip.budget[key])}</strong></div><div className="bar"><i style={{width:`${Math.min(100,Number(trip.budget[key])/Math.max(1,total)*100)}%`}}/></div></div>)}<small>估算口径，非商家实时报价。</small></div></div></div>
      <section className="replan"><div><span className="eyebrow">PLANS CHANGE. WE ADAPT.</span><h3>第 {day} 天有变化？局部调整就好。</h3><p>保留已锁定预约和不受影响的安排；若无法满足约束，会明确提示。</p></div><div className="change-actions"><div className="change-tabs">{[["rain","☂ 下雨了"],["closure","⌖ 地点关闭"],["budget","¥ 调整预算"]].map(([id,label])=><button className={change===id?"chosen":""} key={id} onClick={()=>setChange(id)}>{label}</button>)}</div>{change==="closure"&&<select aria-label="关闭地点" value={closed} onChange={e=>setClosed(e.target.value)}>{items.map(i=><option key={i.item_id} value={i.place_id}>{i.name}{i.locked?"（已锁定）":""}</option>)}</select>}{change==="budget"&&<input aria-label="新的整组预算" type="number" min={1} value={newBudget} onChange={e=>setNewBudget(Number(e.target.value))}/>}<button className="primary" disabled={busy||(change==="closure"&&!closed)} onClick={()=>void replan()}>{busy?"正在重排…":"重新安排这一天 ↗"}</button></div></section>
      {trip.version>1&&<div className="change-summary">版本 v{trip.version} · 本次调整 {trip.changes.changed_item_ids.length} 个条目 · 保留 {trip.changes.preserved_item_ids?.length||0} 个条目。旧版本已存档。</div>}
      <details className="revision-history"><summary>查看版本记录（{revisions.length}）</summary>{revisions.map(r=><p key={r.version}>v{r.version} · {{initial:"初始规划",rain:"雨天重排",closure:"地点关闭",budget:"预算调整"}[r.changes.reason]||r.changes.reason} · {money(r.budget.total_cents)} · {r.items.length} 个安排</p>)}</details>
      <p className="footnote">交通为距离估算。约束通过仅相对于当前输入与估算值，真实开放时间、价格及预约需出发前核验。</p></>:<div className="empty-plan"><span className="empty-route">⌁</span><span className="eyebrow">A LITTLE PLAN, A GREAT JOURNEY</span><h2>你的旅程，还差一个开始。</h2><p>选一个目的地，告诉我们时间和预算。<br/>旅行安排、费用明细与变化预案，一起准备好。</p><div className="empty-features"><span>⌖ 偏好匹配</span><span>◷ 时间校验</span><span>▣ 预约保留</span></div></div>}</section></div>}
      <footer>TripWeaver <span>·</span> 留住确定的安排，接住旅途的变化。<small>Built on LangGraph · 旅行草案，不提供预订服务</small></footer>
    </main></div></div>
}
