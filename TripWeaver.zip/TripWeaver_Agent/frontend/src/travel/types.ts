export interface Place {place_id:string;name:string;city:string;indoor:boolean;category:string;cost_cny:number;tags:string[];description:string}
export interface Item {item_id:string;place_id:string;name:string;day:number;start:string;end:string;cost_cents:number;locked:boolean;indoor:boolean;category:string;note:string;lat:number;lon:number}
export interface Trip {trip_id:string;version:number;session_id:string;request:{city:string;start_date:string;days:number;people:number;budget_cny:number};items:Item[];days:{day:number;date:string}[];budget:Record<string,number|string>;validation:{feasible:boolean;issues:{code:string;message:string;day?:number}[];externally_verified:boolean};changes:{reason:string;changed_item_ids:string[];preserved_item_ids?:string[]};warnings:string[];updated_at:string}
export interface Status {mode:string;agent_enabled:boolean;cities:string[];catalog_size:number;retrieval:string;catalog_is_demo:boolean;map_configured:boolean}
export interface Preference {memory_id:string;statement:string;kind:string;version:number}
export interface Message {id:string;role:string;content:string}
export interface Approval {id:string;label:string;arguments:string|Record<string,unknown>}
