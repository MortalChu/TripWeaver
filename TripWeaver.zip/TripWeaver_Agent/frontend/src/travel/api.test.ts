import {describe,it,expect} from "vitest";
import {money,readEvents} from "./api";

describe("travel client",()=>{
  it("formats cents without losing negative remaining budget",()=>{
    expect(money(12345)).toBe("¥123.45");expect(money(-100)).toBe("¥-1");
  });
  it("parses chunked SSE while ignoring keep-alive frames",async()=>{
    const encoder=new TextEncoder();const events:Record<string,unknown>[]=[];
    const stream=new ReadableStream<Uint8Array>({start(c){
      c.enqueue(encoder.encode(': keep-alive\n\ndata: {"type":"TEXT_MESSAGE_'));
      c.enqueue(encoder.encode('CONTENT","delta":"杭州"}\n\ndata: {"type":"RUN_FINISHED"}\n\n'));c.close();
    }});
    await readEvents(new Response(stream),e=>events.push(e));
    expect(events).toHaveLength(2);expect(events[0].delta).toBe("杭州");
  });
  it("reports server errors",async()=>{
    await expect(readEvents(new Response(JSON.stringify({detail:"尚未配置模型"}),{status:503}),()=>{})).rejects.toThrow("尚未配置模型");
  });
});
