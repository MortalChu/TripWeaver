export const traveler = import.meta.env.VITE_TRAVELER_ID || "demo-traveler";
export const headers = () => ({"Content-Type":"application/json","X-Traveler-ID":traveler,
  ...(sessionStorage.getItem("tripweaver-token") ? {Authorization:`Bearer ${sessionStorage.getItem("tripweaver-token")}`} : {})});
export async function request<T>(path:string,options:RequestInit={}):Promise<T> {
  const response=await fetch(path,{...options,headers:{...headers(),...options.headers}});
  if(!response.ok) { const data=await response.json().catch(()=>({detail:"服务暂不可用"}));
    throw new Error(typeof data.detail==="string"?data.detail:JSON.stringify(data.detail)); }
  return response.json();
}
export function money(cents:number|string):string {return `¥${(Number(cents)/100).toLocaleString("zh-CN",{maximumFractionDigits:2})}`}
export function nextDate():string {const d=new Date();d.setDate(d.getDate()+7);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
export async function readEvents(response:Response,onEvent:(event:Record<string,unknown>)=>void):Promise<void> {
  if(!response.ok) {const body=await response.json();throw new Error(String(body.detail||"Agent请求失败"))}
  if(!response.body)throw new Error("浏览器不支持流式响应");
  const reader=response.body.getReader(),decoder=new TextDecoder();let buffer="";
  try {while(true) {const {value,done}=await reader.read();buffer+=decoder.decode(value,{stream:!done}).replace(/\r\n/g,"\n");
    let boundary;while((boundary=buffer.indexOf("\n\n"))>=0) {const frame=buffer.slice(0,boundary);buffer=buffer.slice(boundary+2);
      const data=frame.split("\n").filter(l=>l.startsWith("data:")).map(l=>l.slice(5).trimStart()).join("\n");
      if(data)onEvent(JSON.parse(data));}
    if(done)break;
  }}finally{reader.releaseLock()}
}
