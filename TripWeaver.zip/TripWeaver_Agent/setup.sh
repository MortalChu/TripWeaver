#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
requirements=requirements.txt
case "${1:-}" in
    '') ;;
    --dev) requirements=requirements-dev.txt ;;
    *) echo 'Usage: sh setup.sh [--dev]; optionally set PYTHON=/path/to/python3.12' >&2; exit 2 ;;
esac
if [ ! -x .venv/bin/python ]; then
    if [ -e .venv ]; then
        echo 'Existing .venv is not usable here. Use a fresh project directory or rename it first.' >&2
        exit 1
    fi
    "${PYTHON:-python3}" -c 'import sys; assert (3, 11) <= sys.version_info[:2] < (3, 14), "Python 3.11-3.13 required; 3.12 recommended"'
    "${PYTHON:-python3}" -m venv .venv
fi
.venv/bin/python -c 'import sys; assert (3, 11) <= sys.version_info[:2] < (3, 14), "Python 3.11-3.13 required; 3.12 recommended"'
.venv/bin/python -m ensurepip --upgrade
.venv/bin/python -m pip install -r "$requirements"
.venv/bin/python -m pip check
if [ ! -f .env ]; then cp .env.example .env; fi
echo 'Environment ready. Edit .env if needed, then run sh start.sh.'
