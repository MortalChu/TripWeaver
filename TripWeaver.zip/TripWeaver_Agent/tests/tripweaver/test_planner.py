import copy
from pathlib import Path
import pytest
from pydantic import ValidationError
from app.domain.travel.models import TripRequest,ReplanRequest,minutes
from app.infrastructure.travel_catalog import TravelCatalog
from app.application.usecases.travel_planner import TravelPlanner

ROOT=Path(__file__).resolve().parents[2]

@pytest.fixture
def planner():
    return TravelPlanner(TravelCatalog(ROOT/"data/travel/places.json").places)

@pytest.mark.parametrize("city",["杭州","成都","上海"])
@pytest.mark.parametrize("pace",["relaxed","balanced","active"])
@pytest.mark.parametrize("transport",["driving","walking"])
def test_schedule_respects_time_and_budget(planner,city,pace,transport):
    result=planner.plan(TripRequest(city=city,start_date="2026-10-01",budget_cny=5000,pace=pace,transport=transport))
    assert result["validation"]["feasible"]
    assert not result["validation"]["externally_verified"]
    assert result["budget"]["total_cents"]<=result["budget"]["limit_cents"]
    assert len({i["place_id"] for i in result["items"]})==len(result["items"])
    for route in result["routes"]:
        assert route["available_minutes"]>=route["minutes"]
        assert not route["verified"]
    for item in result["items"]:
        assert 540<=minutes(item["start"])<minutes(item["end"])<=1080

def reserved():
    return TripRequest(city="杭州",start_date="2026-10-01",budget_cny=4000,reservations=[
        {"reservation_id":"museum-booking","place_id":"HZ001","day":2,"start":"10:00","end":"11:30","total_cost_cny":60}])

def test_rain_replan_preserves_locks_and_other_days(planner):
    original=planner.plan(reserved());snapshot=copy.deepcopy(original)
    result=planner.replan(original,ReplanRequest(expected_version=1,reason="rain",affected_day=2))
    assert original==snapshot
    assert [i for i in result["items"] if i["locked"]]==[i for i in original["items"] if i["locked"]]
    assert [i for i in result["items"] if i["day"]!=2]==[i for i in original["items"] if i["day"]!=2]
    assert all(i["indoor"] for i in result["items"] if i["day"]==2)

def test_closed_locked_reservation_reports_conflict_without_changing_it(planner):
    original=planner.plan(reserved())
    result=planner.replan(original,ReplanRequest(expected_version=1,reason="closure",affected_day=2,closed_place_ids=["HZ001"]))
    assert [i for i in result["items"] if i["locked"]]==[i for i in original["items"] if i["locked"]]
    assert "LOCKED_CONFLICT" in {i["code"] for i in result["validation"]["issues"]}

def test_closure_removes_unlocked_place(planner):
    original=planner.plan(reserved())
    target=next(i for i in original["items"] if i["day"]==1 and not i["locked"])
    result=planner.replan(original,ReplanRequest(expected_version=1,reason="closure",affected_day=1,closed_place_ids=[target["place_id"]]))
    assert target["place_id"] not in {i["place_id"] for i in result["items"]}
    assert target["item_id"] in result["changes"]["removed_item_ids"]

def test_impossible_budget_is_not_reported_as_success(planner):
    original=planner.plan(reserved())
    result=planner.replan(original,ReplanRequest(expected_version=1,reason="budget",affected_day=1,new_budget_cny=10))
    assert not result["validation"]["feasible"]
    assert any(i["code"]=="OVER_BUDGET" for i in result["validation"]["issues"])
    assert [i for i in result["items"] if i["day"]!=1]==[i for i in original["items"] if i["day"]!=1]

def test_overlapping_reservations_are_kept_and_flagged(planner):
    request=reserved()
    data=request.model_dump(mode="json")
    data["reservations"].append({"reservation_id":"second","place_id":"HZ003","day":2,"start":"10:30","end":"12:00","total_cost_cny":50})
    result=planner.plan(TripRequest.model_validate(data))
    assert len([i for i in result["items"] if i["locked"]])==2
    assert "TRANSFER_CONFLICT" in {i["code"] for i in result["validation"]["issues"]}

@pytest.mark.parametrize("patch",[{"days":0},{"people":0},{"budget_cny":float("nan")},{"daily_start":"25:00"},
                                   {"daily_end":"08:00"},{"rainy_days":[4]},{"budget_cny":-10}])
def test_invalid_input_rejected(patch):
    with pytest.raises(ValidationError):
        TripRequest.model_validate({"city":"杭州","start_date":"2026-10-01",**patch})

def test_unknown_city_rejected(planner):
    with pytest.raises(ValueError,match="城市"):
        planner.plan(TripRequest(city="未知城市",start_date="2026-10-01"))

def test_budget_counts_people_and_nights_once(planner):
    request=TripRequest(city="杭州",start_date="2026-10-01",days=3,people=2,budget_cny=10000,
                        food_per_person_day_cny=80,lodging_per_night_cny=300,intercity_total_cny=500)
    budget=planner.plan(request)["budget"]
    assert budget["food_cents"]==48000
    assert budget["lodging_cents"]==60000
    assert budget["intercity_cents"]==50000

def test_family_accessibility_and_rain_filters(planner):
    result=planner.plan(TripRequest(city="杭州",start_date="2026-10-01",days=1,people=1,budget_cny=1500,
                                   rainy_days=[1],family=True,step_free=True))
    assert result["items"]
    assert all(planner.places[i["place_id"]].indoor and planner.places[i["place_id"]].step_free for i in result["items"])
