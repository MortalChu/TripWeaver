import json
from dataclasses import replace
from pathlib import Path
from unittest.mock import AsyncMock
import httpx
import pytest
from app.infrastructure.travel_catalog import TravelCatalog
from app.infrastructure.travel_providers import AmapProvider
from app.infrastructure.travel_memory import DemoLexicalEmbedder
from app.infrastructure.settings import load_settings

ROOT=Path(__file__).resolve().parents[2]

async def test_bm25_filters_and_rank():
    catalog=TravelCatalog(ROOT/"data/travel/places.json")
    result=await catalog.search("艺术", "杭州",indoor=True)
    assert result["places"] and result["recall_strategy"]=="bm25"
    assert all(p["city"]=="杭州" and p["indoor"] for p in result["places"])
    assert "艺术" in result["places"][0]["tags"]
    assert not result["verified"]

async def test_real_local_qdrant_hybrid_then_explicit_fallback(tmp_path,monkeypatch):
    monkeypatch.setenv("TRIPWEAVER_MODE","demo")
    settings=replace(load_settings(),data_dir=tmp_path,reranker_base_url="")
    catalog=TravelCatalog(ROOT/"data/travel/places.json",settings,embedder=DemoLexicalEmbedder())
    try:
        await catalog.startup(live=True)
        assert catalog.vector_ready,catalog.degradation
        result=await catalog.search("艺术","杭州",indoor=True)
        assert result["recall_strategy"]=="bm25_dense_rrf"
        assert all(p["city"]=="杭州" for p in result["places"])
        catalog.embedder.embed=AsyncMock(side_effect=RuntimeError("offline"))
        failed=await catalog.search("艺术","杭州")
        assert failed["recall_strategy"]=="bm25"
        assert any("失败" in w for w in failed["warnings"])
    finally:
        await catalog.close()

async def test_reranker_failure_is_visible():
    ranker=type("Bad",(),{"rerank":AsyncMock(side_effect=ValueError("bad scores"))})()
    catalog=TravelCatalog(ROOT/"data/travel/places.json",reranker=ranker)
    result=await catalog.search("文化","杭州")
    assert result["places"] and not result["rerank_applied"]
    assert any("精排不可用" in w for w in result["warnings"])

async def test_weather_date_coverage_and_provider_rejection():
    payload={"status":"1","forecasts":[{"casts":[{"date":"2026-10-01","dayweather":"小雨"}]}]}
    provider=AmapProvider("fake-test-key",transport=httpx.MockTransport(lambda r:httpx.Response(200,json=payload)))
    assert (await provider.weather("杭州","2026-10-01"))["verified"]
    assert not (await provider.weather("杭州","2026-12-01"))["verified"]
    rejected=AmapProvider("fake-test-key",transport=httpx.MockTransport(lambda r:httpx.Response(200,json={"status":"0"})))
    result=await rejected.weather("杭州","2026-10-01")
    assert not result["verified"] and "fake-test-key" not in json.dumps(result)

async def test_provider_timeout_does_not_expose_credential():
    def unavailable(request):
        raise httpx.ConnectTimeout("secret url",request=request)
    provider=AmapProvider("do-not-expose",transport=httpx.MockTransport(unavailable))
    result=await provider.search("杭州","公园")
    assert not result["verified"] and "do-not-expose" not in json.dumps(result)
