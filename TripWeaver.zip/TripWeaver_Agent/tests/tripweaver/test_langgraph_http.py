"""从 live 装配根验证 LangGraph、AG-UI 流、审批与持久化；外部模型/向量使用替身。"""
import json
import sys
from fastapi.testclient import TestClient
from langchain_core.messages import AIMessage
from tests.tripweaver.test_langgraph import ScriptedModel,call
from app.infrastructure.travel_memory import DemoLexicalEmbedder
from app.presentation.travel_server import build_app


def frames(response):
    return [json.loads(line[5:]) for line in response.text.splitlines() if line.startswith("data:")]


def body(run="run-1",resume=None):
    value={"threadId":"http-session","runId":run,"messages":[{"id":"u-"+run,"role":"user","content":"杭州两天，请记住我喜欢安静住宿"}],
           "tools":[],"context":[],"state":{},"forwardedProps":{"buyerId":"demo-traveler"}}
    if resume:
        value["resume"]=[{"interruptId":resume,"status":"resolved","payload":{"approved":True}}]
    return value


def configure(monkeypatch,tmp_path,replies):
    monkeypatch.setenv("TRIPWEAVER_MODE","live");monkeypatch.setenv("DATA_DIR",str(tmp_path))
    monkeypatch.setenv("LLM_API_KEY","test-local-model");monkeypatch.setenv("TOKEN_BUDGET_TOTAL","0")
    monkeypatch.setenv("LLM_MIN_INTERVAL_SECONDS","0");monkeypatch.delenv("DATABASE_URL",raising=False)
    monkeypatch.setattr("app.infrastructure.embedding.openai_embedding_client.OpenAIEmbeddingClient",lambda *args:DemoLexicalEmbedder())
    model=ScriptedModel(replies)
    class MemoryModel:
        async def ainvoke(self,messages,**kwargs):
            data=json.loads(messages[-1].content)
            return AIMessage(content=json.dumps({"facts":[{"kind":data["kind"],"statement":data["input"],
                "evidence":data["input"],"durable":True,"confidence":.99}]}),usage_metadata={"input_tokens":10,"output_tokens":10,"total_tokens":20})
    monkeypatch.setattr("app.infrastructure.langgraph_model.create_travel_model",lambda settings,role:MemoryModel() if role=="memory" else model)
    monkeypatch.setattr("app.application.agents.langgraph_travel.create_travel_model",lambda settings,role:model)
    return model


def test_live_graph_sse_replay_and_no_agentscope_dependency(tmp_path,monkeypatch):
    model=configure(monkeypatch,tmp_path,[[call("create_trip",{"city":"杭州","start_date":"2026-10-01","days":2})],"行程已经保存。"])
    with TestClient(build_app()) as client:
        assert client.get("/travel/status").json()["framework"]=="langgraph"
        response=client.post("/travel/agent/run",json=body())
        assert response.status_code==200,response.text
        events=frames(response)
        assert "RUN_ERROR" not in {event["type"] for event in events},response.text
        assert {"RUN_FINISHED","TEXT_MESSAGE_CONTENT","TOOL_CALL_RESULT"}<={event["type"] for event in events}
        assert len(client.get("/travel/trips").json()["trips"])==1
        calls=len(model.inputs)
        replay=client.post("/travel/agent/run",json=body())
        assert "RUN_FINISHED" in replay.text and len(model.inputs)==calls
        history=client.get("/travel/agent/history?session_id=http-session").json()
        assert history["messages"] and history["run"]["status"]=="completed"
        cursor=history["run"]["cursor"]
        assert client.get(f"/travel/agent/runs/run-1/events?buyer_id=demo-traveler&after={cursor}").text==""
        assert client.get("/commerce/skills").status_code==404
        assert not any(module.startswith("agentscope") for module in sys.modules)


def test_http_approval_survives_server_restart_then_resumes_once(tmp_path,monkeypatch):
    model=configure(monkeypatch,tmp_path,[[call("remember_preference_tool",{"statement":"喜欢安静住宿"})],"偏好已保存。"])
    with TestClient(build_app()) as client:
        response=client.post("/travel/agent/run",json=body())
        assert "RUN_ERROR" not in response.text,response.text
        assert client.get("/travel/preferences").json()["preferences"]==[]
        history=client.get("/travel/agent/history?session_id=http-session").json()
        approval=history["state"]["toolApprovals"][0]["id"]
        assert client.post("/travel/agent/run",json=body("forged",resume="wrong-id")).status_code==409
    with TestClient(build_app()) as client:
        history=client.get("/travel/agent/history?session_id=http-session").json()
        assert history["state"]["toolApprovals"][0]["id"]==approval
        response=client.post("/travel/agent/run",json=body("resume-1",resume=approval))
        assert "RUN_FINISHED" in response.text and "RUN_ERROR" not in response.text,response.text
        assert len(client.get("/travel/preferences").json()["preferences"])==1
        assert client.post("/travel/agent/run",json=body("resume-again",resume=approval)).status_code==409
        history=client.get("/travel/agent/history?session_id=http-session").json()
        assert history["state"]["toolApprovals"]==[]
