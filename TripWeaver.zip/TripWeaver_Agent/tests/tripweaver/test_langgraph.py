"""真实 LangGraph/SQLite/checkpoint/interrupt，模型响应为可控替身。"""
import asyncio
import copy
import json
from dataclasses import replace
from types import SimpleNamespace

import pytest
from langchain_core.messages import AIMessageChunk, HumanMessage, AIMessage, ToolMessage
from app.application.agents.contracts import SubmitIntentInput
from app.application.agents.langgraph_travel import LangGraphTravelAgent, CURRENT, Turn
from app.infrastructure.eventbus import TradeEventBus
from app.infrastructure.persistence.context_evidence import ContextEvidenceStore
from app.travel_composition import build_travel_container


def call(name,args,identifier="call-1"):
    return {"name":name,"args":args,"id":identifier}


class ScriptedModel:
    def __init__(self,replies):
        self.replies=list(replies);self.inputs=[];self.schemas=[]

    def bind_tools(self,tools):
        self.schemas=[tool.name for tool in tools]
        return self

    async def astream(self,messages):
        self.inputs.append(copy.deepcopy(messages))
        reply=self.replies.pop(0) if self.replies else "处理完成。"
        if isinstance(reply,list):
            yield AIMessageChunk(content="",tool_call_chunks=[{"name":c["name"],"args":json.dumps(c["args"],ensure_ascii=False),"id":c["id"],"index":i} for i,c in enumerate(reply)])
        else:
            for text in [reply[:len(reply)//2],reply[len(reply)//2:]]:
                yield AIMessageChunk(content=text)
        yield AIMessageChunk(content="",usage_metadata={"input_tokens":12,"output_tokens":8,"total_tokens":20})


@pytest.fixture
async def setup(tmp_path,monkeypatch):
    monkeypatch.setenv("TRIPWEAVER_MODE","demo");monkeypatch.setenv("DATA_DIR",str(tmp_path))
    monkeypatch.delenv("DATABASE_URL",raising=False)
    container=await build_travel_container()
    graphs=[]
    async def build(replies,workers=None,**overrides):
        models={"supervisor":ScriptedModel(replies),**{k:ScriptedModel(v) for k,v in (workers or {}).items()}}
        settings=replace(container.settings,llm_api_key="test",token_budget_total=0,llm_min_interval_seconds=0,**overrides)
        graph=await LangGraphTravelAgent.create(settings,container.service,container.preferences,container.session_store,
            TradeEventBus(),ContextEvidenceStore(tmp_path/"evidence.db"),model_factory=lambda role:models.setdefault(role,ScriptedModel([])))
        graphs.append(graph)
        return graph,models
    yield container,build
    for graph in graphs:
        await graph.close()
        graph.connection=None
    await container.shutdown()


def intent(text="杭州两天",session="session-a",owner="user-a",confirmations=()):
    return SubmitIntentInput(session,owner,"zh-CN","CNY",text,confirmations=confirmations)


async def test_actual_state_graph_calls_travel_tool_and_persists_checkpoint(setup):
    container,build=setup
    graph,models=await build([[call("create_trip",{"city":"杭州","start_date":"2026-10-01","days":2})],"已保存行程，演示数据需要核验。"])
    events=[]
    result=await graph.handle_intent(intent(),event_observer=events.append)
    assert result.error is None,result
    trips=container.service.store.list("user-a")
    assert len(trips)==1
    state=await graph.graph.aget_state(graph.config("user-a","session-a"))
    assert state.values["iterations"]==2
    assert any(isinstance(m,ToolMessage) for m in state.values["messages"])
    assert {e["type"] for e in events}>={"tool_start","tool_result","text_delta"}
    assert not any("order" in name for name in models["supervisor"].schemas)


@pytest.mark.parametrize("approved",[True,False])
async def test_interrupt_resume_after_new_graph_instance_requires_correct_approval(setup,approved):
    container,build=setup
    graph,_=await build([[call("remember_preference_tool",{"statement":"喜欢安静的住宿"})]])
    events=[]
    first=await graph.handle_intent(intent("请记住我喜欢安静的住宿"),event_observer=events.append)
    assert first.error is None
    assert await container.preferences.list_by_buyer("user-a")==[]
    approval=next(e for e in events if e["type"]=="approval")["approvals"][0]
    await graph.close();graph.connection=None
    restored,_=await build(["记忆操作已处理。"])
    wrong=await restored.handle_intent(intent(confirmations=({"interrupt_id":"forged","approved":True},)))
    assert "先批准或拒绝" in wrong.final_text
    assert await container.preferences.list_by_buyer("user-a")==[]
    result=await restored.handle_intent(intent(confirmations=({"interrupt_id":approval["id"],"approved":approved},)))
    assert result.error is None,result
    assert len(await container.preferences.list_by_buyer("user-a"))==int(approved)
    again=await restored.handle_intent(intent(confirmations=({"interrupt_id":approval["id"],"approved":approved},)))
    assert "失效" in again.final_text
    assert len(await container.preferences.list_by_buyer("user-a"))==int(approved)


async def test_multiple_memory_calls_pause_before_any_write_and_preserve_decisions(setup):
    container,build=setup
    graph,_=await build([[call("remember_preference_tool",{"statement":"喜欢安静住宿"},"m1"),
                         call("remember_preference_tool",{"statement":"喜欢慢节奏旅行"},"m2")],"完成"])
    events=[]
    await graph.handle_intent(intent(),event_observer=events.append)
    first=next(e for e in events if e["type"]=="approval")["approvals"][0]
    events=[]
    await graph.handle_intent(intent(confirmations=({"interrupt_id":first["id"],"approved":False},)),event_observer=events.append)
    assert not await container.preferences.list_by_buyer("user-a")
    second=next(e for e in events if e["type"]=="approval")["approvals"][0]
    result=await graph.handle_intent(intent(confirmations=({"interrupt_id":second["id"],"approved":True},)))
    assert result.error is None,result
    prefs=await container.preferences.list_by_buyer("user-a")
    assert len(prefs)==1 and prefs[0].statement=="喜欢慢节奏旅行"


async def test_independent_workers_run_in_parallel_and_cannot_write(setup,monkeypatch):
    container,build=setup
    graph,models=await build([[call("task_dispatch",{"subagent_type":"destination","demands":"查杭州"},"d1"),
                              call("task_dispatch",{"subagent_type":"destination","demands":"查上海"},"d2")],"专家完成"],
        workers={"destination":[[call("search_places",{"city":"杭州","query":"文化"},"s1")],
                                [call("search_places",{"city":"上海","query":"文化"},"s2")],"完成","完成"]})
    active=0;maximum=0;both=asyncio.Event()
    original=container.service.catalog.search
    async def search(*args,**kwargs):
        nonlocal active,maximum
        active+=1;maximum=max(maximum,active)
        if active==2:both.set()
        await asyncio.wait_for(both.wait(),2)
        try:return await original(*args,**kwargs)
        finally:active-=1
    monkeypatch.setattr(container.service.catalog,"search",search)
    result=await graph.handle_intent(intent())
    assert result.error is None,result
    assert maximum==2
    assert set(models["destination"].schemas)=={"search_places","live_place_search","travel_evidence_lookup"}
    assert not container.service.store.list("user-a")
    human_inputs=[[m.text for m in messages if isinstance(m,HumanMessage)] for messages in models["destination"].inputs]
    assert all(not ("查杭州" in texts and "查上海" in texts) for texts in human_inputs)


async def test_budget_exhaustion_never_calls_model(setup):
    _,build=setup
    graph,models=await build(["不应调用"])
    graph.settings=replace(graph.settings,token_budget_total=1)
    result=await graph.handle_intent(intent())
    assert result.error is None and "预算不足" in result.final_text
    assert models["supervisor"].inputs==[]


async def test_session_owner_and_checkpoints_isolated(setup):
    _,build=setup
    graph,_=await build(["你好"])
    await graph.handle_intent(intent())
    with pytest.raises(ValueError):
        await graph.handle_intent(intent(owner="another"))
    state=await graph.graph.aget_state(graph.config("another","session-a"))
    assert not state.values


async def test_atomic_trip_operation_receipt_prevents_replay(setup):
    from app.domain.travel.models import TripRequest,ReplanRequest
    container,_=setup
    request=TripRequest(city="杭州",start_date="2026-10-01")
    first=await container.service.create("user-a","s",request,operation_id="create-once")
    second=await container.service.create("user-a","s",request,operation_id="create-once")
    assert first==second and len(container.service.store.list("user-a"))==1
    change=ReplanRequest(expected_version=1,reason="rain",affected_day=1)
    updated=await container.service.replan("user-a",first["trip_id"],change,operation_id="rain-once")
    replay=await container.service.replan("user-a",first["trip_id"],change,operation_id="rain-once")
    assert updated==replay and updated["version"]==2


async def test_context_archives_completed_rounds_and_preserves_recent_pairs(setup):
    container,build=setup
    graph,_=await build([])
    graph.settings=replace(graph.settings,context_target_tokens=1)
    messages=[]
    for index in range(4):
        messages += [HumanMessage(content=f"第{index}轮",id=f"h{index}"),
                     AIMessage(content="",tool_calls=[call("search_places",{},f"t{index}")],id=f"a{index}"),
                     ToolMessage(content="原始地点资料"*100,tool_call_id=f"t{index}",id=f"r{index}")]
    token=CURRENT.set(Turn("user-a","context-session",None,None,0))
    try:
        changes=await graph._context({"messages":messages})
        assert {m.id for m in changes["messages"]}=={"h0","a0","r0","h1","a1","r1"}
        ref=json.loads(changes["summary"])["source_ref"]
        archived=await graph.evidence.get("user-a","context-session",ref)
        assert len(archived["data"]["messages"])==6
        assert await graph.evidence.get("someone-else","context-session",ref) is None
    finally:CURRENT.reset(token)
