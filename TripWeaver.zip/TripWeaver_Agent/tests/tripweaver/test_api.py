from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from app.presentation.travel_server import build_app

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv("TRIPWEAVER_MODE","demo")
    monkeypatch.setenv("DATA_DIR",str(tmp_path))
    monkeypatch.delenv("DATABASE_URL",raising=False)
    monkeypatch.delenv("LLM_API_KEY",raising=False)
    with TestClient(build_app()) as value:
        yield value

def create(client,**kwargs):
    response=client.post("/travel/trips",json={"session_id":"session-a","request":{"city":"杭州","start_date":"2026-10-01",**kwargs}})
    assert response.status_code==201,response.text
    return response.json()

def test_demo_starts_without_secret_and_discloses_limits(client):
    body=client.get("/health").json()
    assert body["mode"]=="demo" and not body["agent_enabled"]
    assert body["retrieval"]=="bm25" and body["catalog_is_demo"]
    assert client.get("/").status_code==200

def test_hmac_travel_identity_rejects_missing_and_mismatched_tokens(tmp_path,monkeypatch):
    from app.infrastructure.identity import IdentityPolicy
    secret="tripweaver-test-secret-32-characters-only"
    monkeypatch.setenv("TRIPWEAVER_MODE","demo")
    monkeypatch.setenv("DATA_DIR",str(tmp_path))
    monkeypatch.setenv("IDENTITY_MODE","hmac")
    monkeypatch.setenv("IDENTITY_HMAC_SECRET",secret)
    monkeypatch.delenv("DATABASE_URL",raising=False)
    policy=IdentityPolicy(mode="hmac",secret=secret)
    with TestClient(build_app()) as client:
        assert client.get("/travel/trips").status_code==401
        headers={"Authorization":"Bearer "+policy.issue("traveler-a"),"X-Traveler-ID":"traveler-a"}
        assert client.get("/travel/trips",headers=headers).status_code==200
        headers["X-Traveler-ID"]="traveler-b"
        assert client.get("/travel/trips",headers=headers).status_code==403

def test_trip_cas_history_and_ownership(client):
    first=create(client)
    path=f"/travel/trips/{first['trip_id']}"
    body={"expected_version":1,"reason":"rain","affected_day":2}
    response=client.post(path+"/replan",json=body)
    assert response.status_code==200,response.text
    assert response.json()["version"]==2
    assert client.post(path+"/replan",json=body).status_code==409
    assert len(client.get(path+"/revisions").json()["revisions"])==2
    assert client.get(path,headers={"X-Traveler-ID":"another-user"}).status_code==404
    assert client.get("/travel/trips",headers={"X-Traveler-ID":"another-user"}).json()["trips"]==[]
    assert client.get(path+"/export").json()["version"]==2

def test_restart_restores_trips_and_preferences(tmp_path,monkeypatch):
    monkeypatch.setenv("TRIPWEAVER_MODE","demo");monkeypatch.setenv("DATA_DIR",str(tmp_path))
    monkeypatch.delenv("DATABASE_URL",raising=False)
    with TestClient(build_app()) as first:
        trip=create(first)
        assert first.post("/travel/preferences",json={"statement":"喜欢安静的住宿"}).status_code==200
    with TestClient(build_app()) as second:
        assert second.get(f"/travel/trips/{trip['trip_id']}").json()["version"]==1
        assert second.get("/travel/preferences").json()["preferences"][0]["statement"]=="喜欢安静的住宿"

def test_memory_version_isolation_and_temporary_constraint_rejection(client):
    result=client.post("/travel/preferences",json={"statement":"喜欢安静住宿"})
    assert result.status_code==200,result.text
    pref=result.json()["preferences"][0]
    body={"memory_id":pref["memory_id"],"expected_version":pref["version"],"kind":"like","statement":"喜欢慢节奏行程"}
    assert client.post("/travel/preferences",json=body).status_code==200
    assert client.post("/travel/preferences",json=body).status_code==409
    assert client.get("/travel/preferences",headers={"X-Traveler-ID":"other"}).json()["preferences"]==[]
    assert client.post("/travel/preferences",json={"statement":"这次预算1000元"}).status_code==422
    assert client.delete(f"/travel/preferences/{pref['memory_id']}?expected_version=1").status_code==409
    assert client.delete(f"/travel/preferences/{pref['memory_id']}?expected_version=2").status_code==200
    assert client.get("/travel/preferences").json()["preferences"]==[]

def test_missing_weather_and_demo_route_are_unverified(client):
    assert not client.get("/travel/weather?city=杭州&travel_date=2026-10-01").json()["verified"]
    route=client.get("/travel/routes?origin=HZ001&destination=HZ002").json()
    assert not route["verified"] and route["source"]=="distance_estimate"

def test_session_owned_and_input_strict(client):
    create(client)
    denied=client.post("/travel/trips",headers={"X-Traveler-ID":"other"},json={"session_id":"session-a","request":{"city":"杭州","start_date":"2026-10-01"}})
    assert denied.status_code==403
    invalid=client.post("/travel/trips",json={"session_id":"x","request":{"city":"杭州","start_date":"2026-10-01","unexpected":"x"}})
    assert invalid.status_code==422

def test_live_requires_model_configuration(tmp_path,monkeypatch):
    monkeypatch.setenv("TRIPWEAVER_MODE","live");monkeypatch.setenv("DATA_DIR",str(tmp_path));monkeypatch.delenv("LLM_API_KEY",raising=False)
    with pytest.raises(RuntimeError,match="LLM_API_KEY"):
        with TestClient(build_app()):
            pass
