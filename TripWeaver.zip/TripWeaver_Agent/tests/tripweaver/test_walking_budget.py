from app.domain.travel.models import Place, TripRequest
from app.application.usecases.travel_planner import TravelPlanner


def test_walking_does_not_reserve_driving_cost():
    place = Place(place_id="TEST001",name="预算边界",city="测试城",lat=30,lon=120,
                  category="文化",tags=[],description="测试",indoor=True,duration_minutes=60,cost_cny=30)
    request = TripRequest(city="测试城",start_date="2026-10-01",days=1,people=1,
                          transport="walking",budget_cny=30,food_per_person_day_cny=0)
    trip = TravelPlanner([place]).plan(request)
    assert len(trip["items"]) == 1
    assert trip["budget"]["total_cents"] == 3000
    assert trip["validation"]["feasible"]
