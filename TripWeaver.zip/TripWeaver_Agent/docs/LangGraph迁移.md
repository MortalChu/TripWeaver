# LangGraph 迁移设计与兼容范围

本次将执行框架替换为 LangGraph，而非在 AgentScope 外套一层图。当前依赖锁中没有 agentscope，默认入口的 69 个 Python 源文件依赖闭包没有 AgentScope import；源码备份和旧版 ZIP 单独保留。

| 原实现 | 当前实现 |
| --- | --- |
| AgentScope ReAct / reply_stream | 原生 StateGraph 的 context → model → tools 条件循环 |
| AgentScope FunctionTool / Toolkit | LangChain StructuredTool，按角色白名单注入 |
| 子 Agent reply | 独立编译的专家 StateGraph，通过 task_dispatch 调用 |
| AgentState 持久化 | AsyncSqliteSaver + 用户/会话隔离 thread_id |
| AgentScope 原生记忆审批 | 图节点 interrupt + Command(resume) |
| AgentScope 消息和中间件 | LangChain 消息、图节点内预算/超时/熔断/归档逻辑 |
| AgentScope 事件投影 | 框架无关的旅行事件 → AG-UI/SSE |

Checkpointer 保存短期图状态，SQLite 业务记忆保存跨会话偏好，两者作用不同。实现遵循 LangGraph 官方的 [持久化](https://docs.langchain.com/oss/python/langgraph/persistence)、[Interrupt](https://docs.langchain.com/oss/python/langgraph/interrupts) 和 [子图](https://docs.langchain.com/oss/python/langgraph/use-subgraphs) 模式；当前 pip 版通过 requirements.txt + constraints.txt 安装固定版本，不要求追随文档的新示例 API。

## 审批与重入

审批节点只生成可序列化的请求，不在 interrupt 前写入。一个批次的多个记忆操作按固定顺序逐个确认；全部获得决定后进入工具节点，拒绝项不执行。前端使用 AG-UI `resume.status=resolved`；外部审批 ID 绑定真实 checkpoint interrupt 和 tool_call_id。重启后读同一 checkpoint 恢复；伪造、过期及重复审批均不执行新写入。

行程的 create/replan 以会话、AI 消息 ID 和工具调用 ID 派生 operation_id；回执和行程版本在同一事务写入。长期偏好仍使用原稳定事实去重与 ID/version CAS。取消或崩溃后不会因收到新用户消息自动重跑旧写操作，应先查询权威状态。

## 上下文和工程保护

固定角色提示在前，动态行程、偏好和历史摘要单独注入。压力超过阈值时按完整用户轮次归档，工具调用和结果一起移动，保留最近两轮。摘要直接摘录历史用户文本并保留证据引用，不由模型生成新事实。归档数据按用户和会话隔离。

主图和专家共享请求级预算与模型并发闸门；调用前保守预留，结束后按 usage 结算。模型 SDK 提供有限请求重试，不在整个图外重跑有副作用的流程。只读工具并发、写入顺序执行、重复调用限制、超时与熔断均在图内实现；超大结果存证据后截断并提示回查。

## 迁移已有数据

旅行行程库、偏好库及合成目录延续使用；新增 `langgraph_checkpoints.sqlite3`，旧 AgentScope AgentState 不转换成 LangGraph 消息。原 SSE 历史可用于展示，但旧版尚未完成的审批不能直接继续，应重新发起当前框架的记忆请求。升级前若曾用旧版 live，请完成/拒绝旧审批并备份运行目录。

发行包不含旧电商入口、AgentScope 代理实现和旧框架测试。少数继承的内部端口仍称 BuyerPreference/ShoppingContext；它们是无框架依赖的身份/领域结构，不参与 AgentScope 执行。
