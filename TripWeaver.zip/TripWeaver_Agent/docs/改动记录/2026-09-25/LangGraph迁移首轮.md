# 2026-09-25 LangGraph 迁移首轮

用户要求把 TripWeaver 从 AgentScope 改为 LangGraph。完成依赖切换、原生 StateGraph 主图和专家图、SQLite Checkpointer、interrupt/Command 审批、LangChain 工具、预算和上下文适配。首轮 56 项测试通过，证据为 `eval/verification/langgraph-20260925/pytest-first.txt`。

HTTP 集成、前端联调及打包跨日继续，最终结果见 [2026-09-26](../2026-09-26/LangGraph迁移.md)。未创建提交，没有远端服务效果验收。
