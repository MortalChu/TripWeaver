# LangGraph 迁移与交付

状态：代码实现和指定本机测试通过，真实远端服务未验收；TripWeaver 2.0.0，未提交。承接[前日首轮](../2026-09-25/LangGraph迁移首轮.md)。

将 AgentScope 编排与工具替换为 LangGraph StateGraph / 专家子图、LangChain StructuredTool，新增 SQLite checkpoint 和 interrupt/Command 审批。继续复用旅行排程、Qdrant/BM25、稳定偏好库、证据库和持久 SSE 日志。创建/重排行程增加原子操作回执；长期记忆模型提炼加入本轮共享预算。关键源码为 langgraph_travel.py、langgraph_model.py、travel_ag_ui.py 与 travel_tools.py。

修复 HTTP 审批协议枚举后，58 项后端测试和 3 项前端测试通过；前端构建成功。失败及复测输出保留，见[验证报告](../../验证报告.md)。旧框架代码移出当前运行源码树，275 个非活动文件单独归档，旧版 ZIP 保留供回滚。

使用 .env.example 启用 demo/live。现有旅行和偏好数据保留，图状态写入独立 langgraph_checkpoints.sqlite3；旧 AgentScope 快照不转换，旧审批需在升级前处理。回滚使用旧 ZIP 和升级前运行数据备份，不混用新旧框架暂停状态。未提供真实远端密钥，未完成模型质量、地图服务、Docker 和线上效果验收。
