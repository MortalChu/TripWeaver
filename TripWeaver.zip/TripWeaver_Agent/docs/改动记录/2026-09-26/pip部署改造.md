# 2026-09-26：venv + pip 部署改造

状态：安装、脚本、Windows 本机启动与后端回归已通过。版本：TripWeaver 2.0.0，installation=venv-pip，最终源码以 MANIFEST.json 标识；未创建 Git 提交。

用户要求取消 uv，并交付修改后的完整启动指南和项目包。新版本安装入口为 requirements.txt / requirements-dev.txt，constraints.txt 固定此前已验证依赖集合；不重新升级 Agent 框架。uv.lock 不进入新包，旧包保留。

新增 setup.ps1/setup.sh 负责环境与依赖准备；start.ps1/start.sh 仅调用 .venv Python 启动。PowerShell 只有显式传 -Port 时才覆盖 PORT，避免默认参数遮蔽 .env。Docker 后端安装与运行改为 pip/Python；Compose 从根目录 .env 读取实际配置。更新 README、完整部署指南、修改清单与迁移说明。

验证：全新 Python 3.12 venv 的 pip 安装成功，pip check 通过；58 项后端回归通过。另由 setup.ps1 新建第二个环境并完成安装，start.ps1 在 PORT=18769 下启动，真实 HTTP 首页、状态、创建、重排通过。PowerShell 语法与 bash -n 通过。模型/地图未使用真实远端服务；Linux、Docker 和其他 Python 版本未实机验收。

证据目录：[pip-20260926](../../../../eval/verification/pip-20260926/)，单项链接见下面。

- [安装脚本输出](../../../../eval/verification/pip-20260926/setup-windows.txt)
- [pip 安装版本与环境](../../../../eval/verification/pip-20260926/install-summary.json)
- [后端回归](../../../../eval/verification/pip-20260926/pytest.txt)
- [HTTP 启动验证](../../../../eval/verification/pip-20260926/startup-smoke.json)
- [语法检查](../../../../eval/verification/pip-20260926/syntax.txt)

启用：在新目录创建 venv、pip 安装依赖并复制用户 .env，默认 demo。回滚：先停止新进程，再启用保留的旧包/环境；两种方式不能同时打开同一运行目录。本次不修改业务实现或数据库结构，不迁移用户数据。
