# TripWeaver Agent

基于 AgentScope 的旅行规划与动态重排系统。从旅行兴趣、时间和预算生成多日草案；天气、地点关闭或预算改变时，只修改受影响的一天，保留已确认预约。包含可运行后端、旅行前端、演示数据、测试与配置。

本项目从用户提供的 `globex_agent.zip` 改造而来。复用了原项目的 AgentScope 执行、上下文治理、SQLite 记忆、Qdrant 检索和 Harness，新增旅行领域、排程算法、局部重排、地点与天气工具及独立页面。来源与改造范围见 [UPSTREAM.md](UPSTREAM.md)。

![行程工作台](eval/verification/tripweaver-20260925/01-itinerary.png)

## 快速启动

需要 Python 3.11–3.13（已用 3.12 验证）和 uv；首次安装依赖需要联网。交付包附带已构建前端，运行演示不需要 Node.js、模型密钥或地图密钥。

```powershell
cd TripWeaver_Agent
uv sync --frozen
uv run python -m app.presentation.travel_main
```

访问 **http://127.0.0.1:8000**。API 文档：`/docs`。Windows 也可以在 PowerShell 执行 `./start.ps1`；它会安装锁定依赖并启动同一入口。

默认 `demo` 模式，数据存入 `data/runtime/`。没有 `.env` 也能运行；如需配置，复制 `.env.example` 为 `.env`。停止后再启动，行程、版本记录与偏好仍保留。不要将个人运行数据库随源码分发。

## 可直接体验的业务流程

1. 选择杭州、成都或上海，填写日期、人数、预算、兴趣和节奏。
2. 可选添加一条自己已确认的预约。系统仅记录预约，不向商家下单。
3. 生成多日行程，查看时间、费用、地点示意、未满足的约束。
4. 选中某一天，点击“下雨了”“地点关闭”或“调整预算”，生成新版本。
5. 核对预约保持不变、其他日期保持不变，查看版本记录或导出 JSON。
6. 在“出行偏好”中保存、修改、删除长期偏好；临时日期、同行人与预约留在旅程内。

## 运行模式与事实边界

| 能力 | demo（默认） | live |
| --- | --- | --- |
| 表单排程、预算、预约锁定、重排、版本恢复 | 可运行 | 同一应用服务 |
| 自然语言对话与三个专家 Agent | 页面明确关闭，不伪装模型回答 | 真实 AgentScope 工具循环 |
| 地点检索 | BM25 关键词匹配 | Embedding + Qdrant + BM25/RRF，可选 HTTP 精排 |
| 长期记忆 | 用户手动确认，规则过滤与词项向量 | 模型提炼 + SQLite 事实/向量 + 语义召回 |
| 天气、路线、地点搜索 | 缺少地图密钥时返回未核验/估算 | 配置高德 Web 服务后查询；超预报范围返回未知 |

内置 **36 个合成地点**，用于演示，不是真实景点营业资料。切到 live 不会自动把示例变成真实数据。导入真实目录见 [地点目录接入](docs/地点目录接入.md)。地图检索只返回候选资料，缺少价格和开放时间时不会擅自加入排程。

当前排程为**单城市、最多 7 天的有约束贪心算法**，不是全局最优路线求解器。交通衔接按距离加缓冲估算；真实导航查询是独立核查工具，其结果尚未自动回写排程矩阵。住宿、餐饮和城际费用使用用户输入估算；不提供酒店库存、预订、付款，也不自动监测天气。雨天/关闭重排由用户或对话工具显式触发。`feasible=true` 仅表示相对于输入和估算通过约束检查；`externally_verified` 始终为 false。

## 启用真实模型

在 `.env` 设置以下变量后重启：

```dotenv
TRIPWEAVER_MODE=live
LLM_BASE_URL=<兼容 chat/completions 的服务地址>
LLM_API_KEY=<你的密钥>
LLM_MODEL=<服务实际开通的聊天模型>
EMBEDDING_MODEL=<服务实际开通的向量模型>
EMBEDDING_DIM=<模型向量维度>
```

Embedding 可用单独的 `EMBEDDING_BASE_URL` / `EMBEDDING_API_KEY`。向量不可用时地点检索显式降级 BM25；长期记忆提炼或向量失败时拒绝保存，不回退为未经提炼的原文。精排需配置独立 `RERANKER_*`，不是用聊天模型假装精排。地图可选配置 `AMAP_API_KEY`。`CONTEXT_SIZE` 应与实际模型能力一致；`TOKEN_BUDGET_TOTAL` 是单轮主代理、子代理和摘要的共享预算。

在线页面支持流式对话、工具调用提示、停止运行和长期记忆批准/拒绝。运行日志支持按游标重连，重复提交同一 runId 只重放，不重跑工具；历史对话存于服务端。API 路径使用 `/travel/agent/*`，内部协议保留 `buyerId` 等兼容字段。

默认身份为演示身份，适合本机体验；它不验证用户真实身份。启动脚本仅监听 127.0.0.1。需要接入认证时参考原 `IdentityPolicy` 的 HMAC 支持；交付不包含账号登录系统。使用嵌入式 Qdrant 时保持 **单个 API worker**。

## 技术栈与代码位置

| 部分 | 实现 |
| --- | --- |
| Agent | Python、AgentScope 2.0.8、Supervisor–Workers、SubAgent as Tool，主代理 15 轮、专家 6 轮 |
| 服务 | FastAPI、Pydantic、AG-UI/SSE、asyncio、SQLAlchemy/SQLite |
| 检索 | OpenAI 兼容 Embedding、Qdrant、应用层 BM25/RRF、可选 HTTP Reranker |
| 记忆和上下文 | SQLite 事实与向量、版本 CAS、原始证据归档、近期轮次保护、压力摘要、稳定系统前缀 |
| 工程保护 | 请求 token 预算、分级超时、网关有限重试、熔断、重复调用检测、工具输出限制 |
| 前端 | React 18、TypeScript、Vite、Markdown、SSE 客户端 |
| 验证 | pytest、FastAPI TestClient、Vitest、真实浏览器操作 |

```text
app/travel_composition.py                 旅行装配根
app/domain/travel/models.py               地点、旅行需求、预约与变更模型
app/application/agents/travel_agent.py     主 Agent 与三类只读专家
app/application/agents/travel_context.py   行程工作集、工具证据归档
app/application/prompts/tripweaver.yml     旅行系统提示
app/application/tools/travel_tools.py      检索、排程、重排、路线、天气工具
app/application/usecases/travel_*.py       约束排程、局部重排与应用服务
app/infrastructure/travel_*.py             目录、地图、版本库、离线记忆适配
app/presentation/travel_server.py          旅行 HTTP 与 AG-UI 路由
frontend/src/TripWeaver.tsx                行程/对话/偏好工作台
data/travel/places.json                    显式标注的合成演示目录
tests/tripweaver/                         新增旅行专项测试
```

保留了上游模块与历史测试用于溯源、复用和对照，但默认入口不装配原商品、订单或支付业务。不要运行历史电商启动脚本并将其当作旅行入口。

## 开发和验证

```powershell
uv run pytest
cd frontend
npm ci
npm run dev
# 修改后构建，后端会托管 dist
npm run build
npm test -- src/travel/api.test.ts
```

前端开发服务 `5173` 将 `/travel` 代理到后端 `8000`。交付验证详情和限制见 [验证报告](docs/验证报告.md)，原始输出见 `eval/verification/tripweaver-20260925/`。脚本模型测试只证明编排、真实工具和持久化联通，不代表任何远端模型的生成质量。未宣称成功率、召回提升或 Prompt Cache 命中率，未进行 SFT / RL 训练。

Docker 可使用 `docker compose -f docker/compose.yml up --build`；配置文件已提供，但当前机器未验证容器构建，推荐先使用上面的本机启动方式。
