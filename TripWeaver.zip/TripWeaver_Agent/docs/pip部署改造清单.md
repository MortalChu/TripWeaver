# TripWeaver：取消 uv 后的完整修改说明

日期：2026-09-26。适用：TripWeaver Agent 2.0.0 / LangGraph，venv + pip 部署版。

这次交付包含完整项目 ZIP、独立环境搭建指南和本说明。新包无需安装或调用 uv；项目本身仍使用 LangGraph，Uvicorn 仍负责运行 HTTP 服务。

## 1. 必须改哪些文件

| 文件 | 操作 | 改动后的行为 |
| --- | --- | --- |
| `requirements.txt` | 新增 | 声明运行依赖，并自动引入 constraints.txt；执行 Python 的 `-m pip install -r requirements.txt` 即可安装 |
| `constraints.txt` | 新增 | 固定已验证的直接及传递依赖版本，保留不同 Python 版本的 NumPy 分支；它只限制版本，不主动安装所有列出的包 |
| `requirements-dev.txt` | 新增 | 引入运行依赖，再安装 pytest/pytest-asyncio；部署环境不必安装测试组件 |
| `setup.ps1` | 新增 | Windows 下创建/检查 .venv、初始化 pip、安装依赖、执行 pip check，并仅在 .env 不存在时复制模板 |
| `setup.sh` | 新增 | Linux/macOS 的对应安装脚本，可用 PYTHON 指定解释器，--dev 安装测试依赖 |
| `start.ps1` | 修改 | 直接使用 .venv/Scripts/python.exe；只负责启动，不自动安装；仅显式传 -Port 时覆盖端口配置 |
| `start.sh` | 修改 | 直接使用 .venv/bin/python；不存在可用环境时提示先安装，不调用 uv |
| `Dockerfile` | 修改 | 删除 uv 镜像复制与 uv 命令；使用 pip 安装运行依赖、pip check 和 python -m uvicorn 启动 |
| `docker/compose.yml` | 修改 | env_file 从 ../.env.example 改为 ../.env，让用户实际配置生效；第一次使用必须准备根目录 .env |
| `pyproject.toml` | 修改 | 移除 tool.uv.workspace 配置并更新依赖说明；保留项目元数据、直接依赖声明、可选实验依赖和 pytest 配置 |
| `README.md` | 修改 | Windows/Linux 的安装、启动、测试命令改用 venv + pip，增加完整部署文档链接 |
| `docs/环境配置与启动指南.md` | 新增 | 包内完整指南，与独立 Markdown 内容一致，覆盖 demo/live、模型、向量、Docker、Linux、HMAC 与故障排查 |
| `docs/pip部署改造清单.md` | 新增 | 本说明的包内副本，便于解压后确认改动范围 |
| `docs/LangGraph迁移.md` | 修改 | 依赖版本固定方式改为 requirements + constraints，Agent 架构说明保留 |
| `docs/验证报告.md` | 修改 | 追加全新 pip 环境安装、回归和启动验证，区分既有前端验证与本轮验证 |
| `docs/改动记录/2026-09-26/pip部署改造.md` | 新增 | 记录需求、改动、验证证据、未实测范围及回滚方式 |
| `docs/改动记录/2026-09-26/README.md` | 修改 | 增加当日 pip 改造索引 |
| `docs/改动记录/README.md` | 修改 | 更新日期总索引中的交付内容 |
| `eval/verification/pip-20260926/` | 新增 | 保存此次安装、版本、测试与真实本机 HTTP 冒烟证据 |
| `MANIFEST.json` | 更新 | 重新记录新包完整文件清单、文件大小和 SHA-256，标识 installation=venv-pip |
| `uv.lock` | 从新包移除 | 新版依赖管理不读取它；原版 ZIP 仍保留，不覆盖原版作为回滚依据 |

## 2. 哪些不需要改

- `app/` 下的 LangGraph 主图、专家、旅行工具、排程器、长期记忆与业务数据库实现不变。
- 前端源码、已构建前端资源、旅行地点样例与原业务测试不变。
- `.env.example` 的模型/地图/数据目录配置语义不变；Compose 改为读取用户复制并填写的 `.env`。
- 没有增加 MySQL、Redis 服务、单独 Qdrant 服务或 GPU 要求；默认仍可本机 demo 启动。
- 不需要修改既有行程/偏好数据库表结构，也没有把数据转换为另一种存储方式。

`uvicorn`、`uvloop` 是服务器及其平台相关依赖，名称与 uv 相近，但并不是 uv 包管理工具。不能因为取消 uv 就将它们全部删除。

历史 upstream 文档、之前的改动记录和原始验证日志保持原样；其中旧安装命令属于历史记录。当前部署请以新 README 和本次指南为准。

## 3. 新版最短启动方式

Windows PowerShell，在新包解压后的 TripWeaver_Agent 根目录执行：

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
.\.venv\Scripts\python.exe -m app.presentation.travel_main
```

若没有 py launcher，使用实际 Python 3.12 的 python.exe 路径创建环境。浏览器打开 http://127.0.0.1:8000，默认 demo，无需模型密钥。

脚本方式：`setup.ps1` 安装，`start.ps1` 启动；Linux 使用 `PYTHON=python3.12 sh setup.sh` 与 `sh start.sh`。setup.ps1 默认用 PATH 中的 python，可通过 -Python 指定实际可执行文件。

## 4. 旧环境怎样切换

建议将新包解压到新目录，不与旧代码混合覆盖。停止旧进程后备份 .env 和整个 DATA_DIR，在新目录创建 venv 并重新安装依赖。随后复制自己的配置并检查路径，停机复制原运行数据，或明确指向已有数据目录。

新旧应用不能同时打开同一个本地 SQLite/Qdrant 运行目录。不要把旧 .venv 复制到新目录；Python 虚拟环境应在实际运行位置创建。旧包和旧环境可保留，回滚时先停止新进程，再按旧方式恢复运行。

## 5. 已验证与未验证

本轮已验证：

- 在全新 Python 3.12 venv 中，通过 pip 安装 requirements-dev.txt 成功；没有调用 uv。
- pip check 返回无依赖冲突；主框架版本仍为 LangGraph 1.2.12。
- 58 项后端测试通过，覆盖旅行业务与真实 LangGraph/SQLite 执行，模型和地图响应使用测试替身。
- 新 setup.ps1 在另一个新环境中完成创建、安装与检查。
- 新 start.ps1 真实启动单进程服务，遵守未显式覆盖时的进程 PORT；首页、状态、行程创建和重排成功。
- PowerShell 脚本和指南命令通过语法检查；Shell 脚本通过 bash -n 检查。

未在本轮执行：Linux/macOS 实机部署、Docker 构建运行、Python 3.11/3.13 安装、真实远端模型/地图验收。前端源码与构建产物未改，本轮沿用既有前端 3 项测试与构建记录，未重复宣称新一轮前端验收。

最终 ZIP 还会检查文件指纹与 CRC，并排除虚拟环境、.env、运行数据库、缓存和 node_modules。具体原始证据见包内 eval/verification/pip-20260926/。
