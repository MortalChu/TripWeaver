"""Validate a catalog without calling external services or writing runtime data."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.infrastructure.travel_catalog import TravelCatalog


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python scripts/validate_travel_catalog.py <catalog.json>")
    catalog = TravelCatalog(Path(sys.argv[1]))
    if not catalog.places:
        raise SystemExit("Catalog must not be empty")
    for place in catalog.places:
        if place.source == "curated" and (not place.source_url or not place.verified_at):
            raise SystemExit(f"{place.place_id}: curated data requires source_url and verified_at")
    print(json.dumps({"valid": True, "places": len(catalog.places),
                      "cities": sorted({p.city for p in catalog.places})}, ensure_ascii=False))
