"""可复现合成旅行目录，全部地点与运营数据为虚构，不做实际出行依据。"""
import json
from pathlib import Path


def main():
    rows = []
    themes = [
        ("城市故事馆","文化",True,["历史","文化","亲子"],75,30),
        ("湖畔漫步道","自然",False,["自然","散步","摄影"],75,0),
        ("手作体验坊","体验",True,["手作","亲子","文化"],90,80),
        ("创意艺术馆","艺术",True,["艺术","摄影","文化"],90,50),
        ("社区风味街","美食",False,["美食","散步"],60,0),
        ("植物温室","自然",True,["自然","植物","亲子"],60,25),
        ("山麓观景台","自然",False,["自然","摄影","登高"],90,20),
        ("旧城记忆巷","文化",False,["历史","文化","摄影"],75,0),
        ("室内科学馆","科技",True,["科技","亲子","雨天"],90,45),
        ("滨水绿地","自然",False,["自然","散步","亲子"],60,0),
        ("书店与阅读空间","休闲",True,["阅读","安静","休闲"],60,0),
        ("城市音乐空间","艺术",True,["音乐","艺术","休闲"],75,60),
    ]
    for prefix,city,lat,lon in [("HZ","杭州",30.25,120.15),("CD","成都",30.66,104.06),("SH","上海",31.23,121.47)]:
        for index,(name,category,indoor,tags,duration,cost) in enumerate(themes,1):
            rows.append({"place_id":f"{prefix}{index:03d}","name":name+"（示例）","city":city,
                         "lat":lat+(index%4)*.008,"lon":lon+(index//4)*.009,
                         "category":category,"tags":tags,"description":f"{city}合成演示地点，适合{'、'.join(tags)}；运营信息为测试设定。",
                         "indoor":indoor,"family_friendly":True,"step_free":index!=7,
                         "duration_minutes":duration,"open_at":"09:00","close_at":"18:00","cost_cny":cost,
                         "source":"synthetic_demo","source_url":"","verified_at":None})
    target = Path(__file__).resolve().parents[1]/"data/travel/places.json"
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(f"Generated {len(rows)} synthetic places")


if __name__ == "__main__":
    main()
