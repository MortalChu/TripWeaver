# 来源与改造说明

输入来自用户提供的 `globex_agent.zip`，SHA-256：`bf9eaa93971e099616021ece11cd7bf4cd9b046bcc7a233d54a71fb2cade7862`。

本交付是该代码的旅行场景衍生改造，当前执行框架为 LangGraph；不声称复用的 Harness 设计、检索、记忆或会话基础设施为全新原创。上游 README 保存在 `docs/upstream/README.globex.md`。含电商用语的通用内部类型（如 ShoppingContext、BuyerPreference）作为无框架依赖的兼容端口复用，旅行入口没有商品购买能力。

新增旅行需求与预约模型、排程/预算算法、锁定预约局部重排、版本库、三类旅行专家及工具、地图适配、地点目录、旅行页面和专项验证。原服务入口及 AgentScope 代码已移出新运行源码树；当前 `server.py` 只指向 LangGraph 旅行服务。

输入压缩包未提供明确的顶层 LICENSE，原 README 的许可证栏仍为待补充。此包保留来源，不重新宣称 MIT/Apache 等许可证；依赖按各自许可证分发。对外发布时应先确认上游许可和所用数据授权。

交付排除了原个人/评测数据库、旧评测产物、知识文档样本、缓存、虚拟环境、node_modules 及非活动框架代码；历史 README 仅供溯源。被排除资料对应的历史文档链接可能不再适用。当前功能和启动方式以根 README 为准。

## 2026-09-26 LangGraph 迁移

TripWeaver 2.0.0 已替换 AgentScope 执行层，安装依赖和运行入口仅使用 LangGraph / LangChain。新发行包只收录旅行运行依赖、相关前端和测试。旧版完整包另存 `TripWeaver_Agent_AgentScope.zip`；不再使用的本机代码归档至工作区同级 `TripWeaver_AgentScope_Reference`。来源和许可说明仍然保留，迁移不改变上游权利归属。
